<?php
// Inclusion du fichier 'emprunt.php'
require 'emprunt.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'EmpruntForm' en utilisant la connexion à la base de données
$form = new EmpruntForm($bdd);

// Récupération des utilisateurs et des livres à partir de la base de données
$users = $form->getUser();
$livres = $form->getLivres();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Emprunter un livre</title>
</head>
<body>
<style>
        html{
            height : 100%;
        }
        body {
            background: linear-gradient(blue, 10%, pink);
        }
        form {
            background-color : pink;
            text-align : center;
            border : solid;
            margin-left : 450px;
            margin-right : 450px;
        }

    /*Navbar*/

		ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
		overflow: hidden;
		}

		li {
		float: left;
		border-right:2px solid #bbb;
		}

		li:last-child {
		border-right: none;
		}

		li a {
		display: block;
		color: white;
		text-align: center;
		padding: 14px 16px;
		text-decoration: none;
		}

		li a:hover:not(.active) {
		background-color: green;
		}

		.active {
		background-color: green;
		}
   </style> 

<!-- Navbar -->
<ul>
<li><a href="../auteurs/add_auteurs.php">Ajouter des auteurs</a></li>
<li><a href="../livres/add_livres.php">Ajouter des livres</a></li>
<li><a href="emprunt_livres.php">Emprunter des livres</a></li>
<li><a href="../index.php">Retourner au menu</a></li>

<br><br><br><br>

<!-- Formulaire emprunt -->
<form action="traitement_emprunt.php" method="post">
    <br>
    <!-- Select User -->
    <label>Utilisateur :</label>
    <select name="user">
    <?php foreach ($users as $user) { ?>
        <option value="<?php echo ($user['id']); ?>">
            <?php echo htmlspecialchars($user['nom']) . ' ' . htmlspecialchars($user['prenom']); ?>
        </option>
    <?php } ?>
    </select><br><br>

    <!-- Select livres -->
    <label>Livre :</label>
    <select name="livre">
    <?php foreach ($livres as $livre) { ?>
        <option value="<?php echo ($livre['id']); ?>">
            <?php echo htmlspecialchars($livre['titre']); ?>
        </option>
    <?php } ?>
    </select><br><br>
    <label for="date_debut">Date de Début :</label>
    <input type="date" id="date_debut" name="date_debut" required><br><br>
    <label for="date_fin">Date de Fin :</label>
    <input type="date" id="date_fin" name="date_fin" required><br><br>
    <input type="submit" value="Emprunter livre">
    <br></br>
</form>
</body>
</html>