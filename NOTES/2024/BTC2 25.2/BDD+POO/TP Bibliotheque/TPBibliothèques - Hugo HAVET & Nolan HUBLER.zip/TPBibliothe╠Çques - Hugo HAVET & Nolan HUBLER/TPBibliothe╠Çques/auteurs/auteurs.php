<?php
// Inclusion du fichier 'Database.php'
require '../Database.php';

// Définition de la classe AuteursForm
class AuteursForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour insérer des auteurs dans la base de données
    public function insertAuteurs($nom, $prenom, $biographie) {
        try {
            // Préparation de la requête SQL pour l'insertion
            $requete = $this->db->prepare("INSERT INTO auteurs (nom, prenom, biographie) VALUES (?, ?, ?)");

            // Exécution de la requête avec les valeurs fournies
            $requete->execute([$nom, $prenom, $biographie]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../index.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion de l'auteur : " . $e->getMessage());
        }
    }
}
?>