<?php
// Inclusion du fichier 'auteurs.php'
require_once 'auteurs.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'AuteursForm' en utilisant la connexion à la base de données
$form = new AuteursForm($bdd);

// Récupération des informations envoyées via la méthode POST du formulaire
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$biographie = $_POST['biographie'];

// Appel de la fonction 'insertAuteurs' pour insérer les informations dans la base de données
$form->insertAuteurs($nom, $prenom, $biographie);
?>