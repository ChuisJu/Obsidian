<?php
// Définition de la classe Database
class Database {
    // Propriétés privées pour stocker les informations de connexion à la base de données
    private $host = "localhost"; // Adresse du serveur MySQL
    private $dbName = "bibliotheques"; // Nom de la base de données
    private $username = "root"; // Nom d'utilisateur MySQL
    private $password = "root"; // Mot de passe MySQL
    private $bdd; // Objet PDO pour la connexion à la base de données

    // Constructeur de la classe
    public function __construct() {
        $this->bdd = null; // Initialisation de l'objet PDO à null

        try {
            // Création d'une connexion PDO à la base de données en utilisant les informations de connexion
            $this->bdd = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbName . ";charset=utf8", $this->username, $this->password);

            // Définition du mode d'erreur PDO sur Exception, ce qui permet de gérer les erreurs avec des exceptions
            $this->bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            // En cas d'erreur lors de la connexion, affichage d'un message d'erreur
            die('Erreur : ' . $e->getMessage());
        }
    }

    // Méthode pour obtenir la connexion à la base de données
    public function getConnection() {
        return $this->bdd; // Retourne l'objet PDO représentant la connexion à la base de données
    }
}
?>