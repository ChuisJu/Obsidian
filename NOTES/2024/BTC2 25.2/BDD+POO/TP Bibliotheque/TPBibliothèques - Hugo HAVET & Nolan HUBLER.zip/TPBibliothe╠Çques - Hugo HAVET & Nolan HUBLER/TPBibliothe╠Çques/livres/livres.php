<?php
// Inclusion du fichier 'Database.php'
require '../Database.php';

// Définition de la classe LivresForm
class LivresForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour récupérer la liste des auteurs depuis la base de données
    public function getAuteurs() {
        try {
            $requete = $this->db->prepare("SELECT id, nom, prenom FROM auteurs");
            $requete->execute();
            return $requete->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Erreur lors de la récupération des auteurs : " . $e->getMessage());
        }
    }

    // Fonction pour insérer un livre dans la base de données
    public function insertLivre($titre, $pages, $date, $auteur_id) {
        try {
            $requete = $this->db->prepare("INSERT INTO livres (titre, nb_pages, date, id_auteurs) VALUES (?, ?, ?, ?)");
            $requete->execute([$titre, $pages, $date, $auteur_id]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../index.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion du livre : " . $e->getMessage());
        }
    }

    // Fonction pour récupérer tous les livres depuis la base de données
    public function getAllLivres() {
        $stmt = $this->db->prepare("SELECT * FROM livres");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>