<?php
// Inclusion du fichier 'auteurs.php' qui semble contenir des fonctions ou des classes nécessaires
require 'auteurs.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'AuteursForm' pour gérer le formulaire d'ajout d'auteurs
$form = new AuteursForm($bdd);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Auteur</title>
</head>
<body>

<style>
        html{
            height : 100%;
        }
        body {
            background: linear-gradient(blue, 10%, pink);
        }
        form {
            background-color : pink;
            text-align : center;
            border : solid;
            margin-left : 450px;
            margin-right : 450px;
        }

    /*Navbar*/

		ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
		overflow: hidden;
		}

		li {
		float: left;
		border-right:2px solid #bbb;
		}

		li:last-child {
		border-right: none;
		}

		li a {
		display: block;
		color: white;
		text-align: center;
		padding: 14px 16px;
		text-decoration: none;
		}

		li a:hover:not(.active) {
		background-color: green;
		}

		.active {
		background-color: green;
		}
   </style> 

		<ul>
		<li><a href="/auteurs/add_auteurs.php">Ajouter des auteurs</a></li>
		<li><a href="../livres/add_livres.php">Ajouter des livres</a></li>
		<li><a href="../emprunt/emprunt_livres.php">Emprunter des livres</a></li>
		<li><a href="../emprunt/index.php">Retourner au menu</a></li>
		</ul>

		<br><br><br><br>

<!-- Formulaire pour ajouter un auteur -->
<form action="traitement_auteurs.php" method="post">
    <br></br>
    <label>Nom :</label><input type="text" name="nom" placeholder="Nom" required><br><br>
    <label>Prénom :</label><input type="text" name="prenom" placeholder="Prénom" required><br><br>
    <label>Biographie :</label><input type="textarea" name="biographie" placeholder="Biographie"required><br><br>
    <input type="submit" value="Ajouter l'auteur">
    <br></br>
</form>
</body>
</html>