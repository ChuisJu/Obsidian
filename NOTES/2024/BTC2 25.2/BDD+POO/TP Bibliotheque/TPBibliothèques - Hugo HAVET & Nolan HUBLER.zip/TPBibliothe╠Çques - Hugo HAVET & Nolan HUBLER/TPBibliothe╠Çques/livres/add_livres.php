<?php
// Inclusion du fichier 'livres.php'
require 'livres.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'LivresForm' en utilisant la connexion à la base de données
$form = new LivresForm($bdd);

// Récupération des auteurs depuis la base de données
$auteurs = $form->getAuteurs();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Livre</title>
</head>
<body>
<style>
        html{
            height : 100%;
        }
        body {
            background: linear-gradient(blue, 10%, pink);
        }
        form {
            background-color : pink;
            text-align : center;
            border : solid;
            margin-left : 450px;
            margin-right : 450px;
        }

    /*Navbar*/

		ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
		overflow: hidden;
		}

		li {
		float: left;
		border-right:2px solid #bbb;
		}

		li:last-child {
		border-right: none;
		}

		li a {
		display: block;
		color: white;
		text-align: center;
		padding: 14px 16px;
		text-decoration: none;
		}

		li a:hover:not(.active) {
		background-color: green;
		}

		.active {
		background-color: green;
		}
   </style> 

<!-- Barre de navigation -->
<ul>
<li><a href="../auteurs/add_auteurs.php">Ajouter des auteurs</a></li>
<li><a href="add_livres.php">Ajouter des livres</a></li>
<li><a href="../emprunt/emprunt_livres.php">Emprunter des livres</a></li>
<li><a href="../emprunt/index.php">Retourner au menu</a></li>
</ul>

<br><br><br><br>

<!-- Formulaire de traitement de livre -->
<form action="traitement_livres.php" method="post">
    <br>
    <label>Titre du livre :</label><input type="text" name="titre" required><br><br>
    <label>Nb Page :</label><input type="number" name="pages" required><br><br>
    <label for="date_debut">Date :</label>
    <input type="date" id="date_debut" name="date" required><br><br>
    <label for="auteur">Auteur :</label>
    <select name="auteur_id">
    <?php foreach ($auteurs as $auteur) { ?>
        <option value="<?php echo ($auteur['id']); ?>">
            <?php echo htmlspecialchars($auteur['nom']) . ' ' . htmlspecialchars($auteur['prenom']); ?>
        </option>
    <?php } ?>
    </select><br><br>
    <input type="submit" value="Ajouter le livre">

    <br></br>
</form>
</body>
</html>