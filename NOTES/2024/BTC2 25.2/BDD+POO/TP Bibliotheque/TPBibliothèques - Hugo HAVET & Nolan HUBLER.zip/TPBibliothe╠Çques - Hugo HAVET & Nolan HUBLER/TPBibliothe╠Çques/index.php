<?php
// Inclusion du fichier 'getAll.php' pour accéder à la classe GetAll
require 'getAll.php';

// Création d'une instance de la classe Database pour établir la connexion à la base de données
$db = new Database();
$bdd = $db->getConnection();

// Création d'une instance de la classe GetAll pour obtenir les données depuis la base de données
$getAll = new GetAll($db);

// Récupération de toutes les informations sur les livres, auteurs et emprunts
$allLivres = $getAll->getAllLivres();
$allAuteurs = $getAll->getAllAuteurs();
$allEmprunts = $getAll->getAllEmprunts();

// Création d'une carte (map) des auteurs pour associer les ID d'auteur aux noms complets
$auteursMap = [];
foreach ($allAuteurs as $auteur) {
    $auteursMap[$auteur['id']] = $auteur['prenom'] . ' ' . $auteur['nom'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Livres et Utilisateurs</title>
    <style>
        /* Styles CSS pour la mise en page */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: linear-gradient(70deg, SlateBlue, MediumSlateBlue, lightblue);
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: left;
            background : #f2f2f2;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour la barre de navigation (navbar) */
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        li {
            float: left;
            border-right: 2px solid #bbb;
        }

        li:last-child {
            border-right: none;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover:not(.active) {
            background-color: green;
        }

        .active {
            background-color: green;
        }

        /* Styles pour le titre */
        h2 {
            margin-left : 600px;
        }
    </style>
</head>
<body>
    <!-- Barre de navigation (navbar) -->
    <ul>
        <li><a href="users/add_users.php">Ajouter des utilisateurs</a></li>
        <li><a href="auteurs/add_auteurs.php">Ajouter des Auteurs</a></li>
        <li><a href="livres/add_livres.php">Ajouter des Livres</a></li>
        <li><a href="emprunt/emprunt_livres.php">Emprunter des Livres</a></li>
    </ul>

    <br>
    <h2>Liste des Livres</h2>
    <br>
    <table border="1">
        <tr>
            <th>Titre</th>
            <th>Nb Page</th>
            <th>Date</th>
            <th>Auteur</th>
        </tr>
        <?php foreach ($allLivres as $allLivre): ?>
            <tr>
                <td><?= htmlspecialchars($allLivre['titre']) ?></td>
                <td><?= htmlspecialchars($allLivre['nb_pages']) ?></td>
                <td><?= htmlspecialchars($allLivre['date']) ?></td>
                <td><?= htmlspecialchars($auteursMap[$allLivre['id_auteurs']]) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h2>Liste des Emprunts</h2>
    <table border="1">
        <tr>
            <th>Titre du Livre</th>
            <th>Emprunté par</th>
            <th>Date de Début</th>
            <th>Date de Fin</th>
        </tr>
        <?php foreach ($allEmprunts as $emprunt): ?>
            <tr>
                <td><?= htmlspecialchars($emprunt['titre']) ?></td>
                <td><?= htmlspecialchars($emprunt['utilisateurs_prenom']) . ' ' . htmlspecialchars($emprunt['utilisateurs_nom']) ?></td>
                <td><?= htmlspecialchars($emprunt['date_debut']) ?></td>
                <td><?= htmlspecialchars($emprunt['date_fin']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>