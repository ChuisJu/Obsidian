<?php
// Inclusion du fichier 'Database.php' pour accéder à la classe Database
require 'Database.php';

// Définition de la classe GetAll
class GetAll {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Méthode pour obtenir tous les livres depuis la base de données
    public function getAllLivres() {
        $pdo = $this->db->getConnection(); // Récupération de l'objet PDO pour la connexion

        // Préparation de la requête SQL pour sélectionner tous les livres
        $stmt = $pdo->prepare("SELECT * FROM livres");
        $stmt->execute(); // Exécution de la requête
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupération des résultats sous forme de tableau associatif
    }  

    // Méthode pour obtenir tous les auteurs depuis la base de données
    public function getAllAuteurs() {
        $pdo = $this->db->getConnection(); // Récupération de l'objet PDO pour la connexion

        // Préparation de la requête SQL pour sélectionner tous les auteurs
        $stmt = $pdo->prepare("SELECT id, nom, prenom FROM auteurs");
        $stmt->execute(); // Exécution de la requête
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupération des résultats sous forme de tableau associatif
    }

    // Méthode pour obtenir tous les emprunts (avec des informations sur les livres et les utilisateurs) depuis la base de données
    public function getAllEmprunts() {
        $pdo = $this->db->getConnection(); // Récupération de l'objet PDO pour la connexion

        // Requête SQL pour sélectionner les emprunts avec des informations sur les livres et les utilisateurs associés
        $sql = "SELECT livres.titre, utilisateurs.nom AS utilisateurs_nom, utilisateurs.prenom AS utilisateurs_prenom, emprunts.date_debut, emprunts.date_fin 
                FROM emprunts
                JOIN livres ON emprunts.id_livres = livres.id 
                JOIN utilisateurs ON emprunts.id_utilisateurs = utilisateurs.id";

        // Préparation de la requête SQL
        $stmt = $pdo->prepare($sql);
        $stmt->execute(); // Exécution de la requête
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupération des résultats sous forme de tableau associatif
    }
}
?>