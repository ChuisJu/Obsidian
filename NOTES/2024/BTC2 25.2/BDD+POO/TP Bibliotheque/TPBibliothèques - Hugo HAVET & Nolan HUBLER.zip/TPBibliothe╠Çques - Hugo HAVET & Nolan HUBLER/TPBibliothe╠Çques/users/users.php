<?php
// Inclusion du fichier 'Database.php'
require '../Database.php';

// Définition de la classe UsersForm
class UsersForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour insérer un utilisateur dans la base de données
    public function insertUsers($nom, $prenom, $email) {
        try {
            $requete = $this->db->prepare("INSERT INTO utilisateurs (nom, prenom, email) VALUES (?, ?, ?)");
            $requete->execute([$nom, $prenom, $email]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../index.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion de l'utilisateur : " . $e->getMessage());
        }
    }
}
?>
