<?php
// Inclusion du fichier 'livres.php'
require_once 'livres.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'LivresForm' en utilisant la connexion à la base de données
$form = new LivresForm($bdd);

// Récupération des informations envoyées via la méthode POST du formulaire
$titre = $_POST['titre'];
$pages = $_POST['pages'];
$date = $_POST['date'];
$auteur_id = (int)$_POST['auteur_id']; // Conversion en entier

// Appel de la fonction 'insertLivre' pour insérer ces informations dans la base de données
$form->insertLivre($titre, $pages, $date, $auteur_id);
?>