<?php
// Inclusion du fichier 'emprunt.php'
require 'emprunt.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'EmpruntForm' en utilisant la connexion à la base de données
$form = new EmpruntForm($bdd);

// Récupération des informations envoyées via la méthode POST du formulaire
$user = intval($_POST['user']); // Conversion en entier
$livre = intval($_POST['livre']); // Conversion en entier
$date_debut = $_POST['date_debut'];
$date_fin = $_POST['date_fin'];

// Appel de la fonction 'insertEmprunt' pour insérer ces informations dans la base de données
$form->insertEmprunt($user, $livre, $date_debut, $date_fin);
?>