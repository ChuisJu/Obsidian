<?php
// Inclusion du fichier 'users.php'
require_once 'users.php';

// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'UsersForm' en utilisant la connexion à la base de données
$form = new UsersForm($bdd);

// Récupération des informations envoyées via la méthode POST du formulaire
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];

// Appel de la fonction 'insertUsers' pour insérer ces informations dans la base de données
$form->insertUsers($nom, $prenom, $email);
?>