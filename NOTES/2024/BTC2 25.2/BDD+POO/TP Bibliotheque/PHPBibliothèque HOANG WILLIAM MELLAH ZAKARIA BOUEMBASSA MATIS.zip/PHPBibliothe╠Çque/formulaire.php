<?php 
//Création de notre option ajout auteur avec les attributs nom,prenom;biographie//
    require 'classe.php';
    if(isset($_POST['AjouterAuteur'])){
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $biographie = $_POST['biographie'];

    $auteur = new Auteur($nom, $prenom, $biographie);
    $biblio->ajouterAuteur($auteur);
    } else if(isset($_POST['AjouterLivre'])){
        $titre = $_POST['titre'];
        $datedepublication = $_POST['datedepublication'];
        $nbPages = $_POST['nbPages'];
        $idAuteur = $_POST['idAuteur'];
        $livre = new Livre($titre, $datedepublication, $nbPages, $idAuteur);
        $biblio->ajouterLivre($livre);
    } else if (isset($_POST['AjouterEmprunt'])){
        $idLivre = $_POST['idLivre'];
        $dateEmprunt = $_POST['dateEmprunt'];
        $dateRetour = $_POST['dateRetour'];
        $idUtilisateur = $_POST['idUtilisateur'];
        $emprunt = new Emprunt($idLivre, $dateEmprunt, $dateRetour, $idUtilisateur);
        $biblio->ajouterEmprunt($emprunt);
    }
    else if (isset($_POST['AjouterUtilisateur'])){
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];

        $utilisateur = new Utilisateur($nom, $prenom, $email);
        $biblio->ajouterUtilisateur($utilisateur);
    }

    

?>