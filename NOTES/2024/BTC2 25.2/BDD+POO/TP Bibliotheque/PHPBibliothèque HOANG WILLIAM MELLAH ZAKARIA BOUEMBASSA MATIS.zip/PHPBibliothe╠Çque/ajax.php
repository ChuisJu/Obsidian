<?php require 'classe.php';

// Retrieve the ID from the URL parameter
$uid = isset($_GET['uid']) ? $_GET['uid'] : '';

$biblio->afficherUtilisateurEmprunts($date, $uid);

?>