DROP DATABASE IF EXISTS `bibli_enligne`;

CREATE DATABASE bibli_enligne;

use bibli_enligne;

CREATE TABLE auteur(
ID INT PRIMARY KEY AUTO_INCREMENT,nom VARCHAR(50),prenom VARCHAR(55),biographie TEXT);

CREATE TABLE livre(
ID INT PRIMARY KEY AUTO_INCREMENT,titre VARCHAR(50),datedepublication DATE,nbPages INT,idAuteur INT, FOREIGN KEY(idAuteur) REFERENCES auteur(ID));

CREATE TABLE utilisateur(
ID INT PRIMARY KEY AUTO_INCREMENT,nom VARCHAR(50),prenom VARCHAR(55),email VARCHAR(55));

CREATE TABLE emprunt(
ID INT PRIMARY KEY AUTO_INCREMENT,idLivre INT, FOREIGN KEY(idLivre) REFERENCES livre(ID),idUtilisateur INT, FOREIGN KEY(idUtilisateur) REFERENCES utilisateur(ID),date_emprunt DATE,date_retour DATE);

INSERT INTO auteur(id,nom,prenom,biographie)VALUES
(1,'Camus','Albert','Albert Camus, né le 7 novembre 1913 à Dréan en Algérie française, et mort par accident le 4 janvier 1960 à Villeblevin en France, est un écrivain, philosophe, journaliste militant, romancier, dramaturge, essayiste et nouvelliste français, lauréat du prix Nobel de littérature en 1957.'),
(2,'Orwell','George','Eric Arthur Blair, plus connu sous son nom de plume George Orwell, né le 25 juin 1903 à Motihari pendant la période du Raj britannique et mort le 21 janvier 1950 à Londres, est un écrivain, essayiste et journaliste britannique.'),
(3,'Follett','Ken','Kenneth Martin Follett dit Ken Follett, CBE, né le 5 juin 1949 à Cardiff, est un écrivain britannique, auteur de romans espionnage thrillers et romans historiques.'),
(4,'Scoot','Orsan','Orson Scott Card, né le 24 août 1951 à Richland dans État de Washington, est un écrivain de science-fiction américain étant notamment illustré dans le genre de la fantasy.'),
(5,'Rothfuus','Patrick','Patrick James Rothfuss, né le 6 juin 1973 à Madison dans le Wisconsin, est un auteur américain de fantasy. ');

INSERT INTO livre(id,titre,datedepublication,nbPages,idAuteur)VALUES
(1,'L\'Etranger','1980-12-24',15,1),
(2,'Le nom du vent','1970-04-02',18,2),
(3,'Le petit prince','1786-08-12',100,3),
(4,'Le meilleur des mondes','1909-09-09',90,4),
(5,'Le seigneur des anneaux','1990-01-01',50,5);

INSERT INTO utilisateur(id,nom,prenom,email)VALUES
(1,'Mellah','Zaki','Zakimellah@gmail.com'),
(2,'Hoang','Wili','Wilihoang@gmail.com'),
(3,'Bou','Matisma','Matismabou@gmail.com'),
(4,'Millon','Alex','Alexmillon@gmail.com'),
(5,'Mellah','Anis','Anismellah@gmail.com');


INSERT INTO emprunt(id,idLivre,date_emprunt,date_retour,idUtilisateur)VALUES
(1,2,'2003-12-24','2004-12-24',1),
(2,3,'2023-10-09','2024-10-09',2),
(3,1,'2022-01-01','2023-01-01',3),
(4,5,'2022-07-01','2023-07-01',4),
(5,4,'2022-10-10','2023-10-10',5);
