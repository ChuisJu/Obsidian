// Ce code JavaScript définit plusieurs fonctions qui contrôlent la visibilité de différentes sections sur notre page web//
function afficherBiblio() {
    document.getElementById("biblio").style.display = "block";
    document.getElementById("emprunt").style.display = "none";
    document.getElementById("auteur").style.display = "none";
    document.getElementById("utilisateur").style.display = "none";
    document.getElementById("utilisateurlivre").style.display = "none";

}
function afficherEmprunt() {
    document.getElementById("biblio").style.display = "none";
    document.getElementById("emprunt").style.display = "block";
    document.getElementById("auteur").style.display = "none";
    document.getElementById("utilisateur").style.display = "none";
    document.getElementById("utilisateurlivre").style.display = "none";

}

function afficherAuteur(){
    document.getElementById("auteur").style.display = "block";
    document.getElementById("biblio").style.display = "none";
    document.getElementById("emprunt").style.display = "none";
    document.getElementById("utilisateur").style.display = "none";
    document.getElementById("utilisateurlivre").style.display = "none";

}

function afficherUtilisateur(){
    document.getElementById("utilisateur").style.display = "block";
    document.getElementById("auteur").style.display = "none";
    document.getElementById("biblio").style.display = "none";
    document.getElementById("emprunt").style.display = "none";
    document.getElementById("utilisateurlivre").style.display = "none";
}
function afficherUtilisateurEmprunts(id){
    fetch('ajax.php?uid=' + id)
        .then(response => response.text())
        .then(data => {
            document.getElementById("utilisateur").style.display = "none";
            document.getElementById("auteur").style.display = "none";
            document.getElementById("biblio").style.display = "none";
            document.getElementById("emprunt").style.display = "none";
            document.getElementById("utilisateurlivre").style.display = "block";
            document.getElementById('utilisateurlivre').innerHTML = data;
        })
        .catch(error => console.error('Error:', error));

}