<?php 
//Ici nous avons nos requetes pour supprimer les differents variables : Livre, Auteur, Emprunt et utilisateur//

    require 'classe.php';
    $id = $_POST['id'];
    if(isset($_POST['SupprLivre'])){
        $biblio->supprimerLivre($id);
    } else if(isset($_POST['SupprAuteur'])){
        $biblio->supprimerAuteur($id);
    } else if(isset($_POST['SupprEmprunt'])){
        $biblio->supprimerEmprunt($id);
    } else if(isset($_POST['SupprUtilisateur'])){
        $biblio->supprimerUtilisateur($id);
    }
    header("Location: index.php");


?>