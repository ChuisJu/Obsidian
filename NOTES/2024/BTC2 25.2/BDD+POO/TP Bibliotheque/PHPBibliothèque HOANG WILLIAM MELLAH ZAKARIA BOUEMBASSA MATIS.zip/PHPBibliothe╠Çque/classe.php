<?php
//création de nos classes avec leurs variables//
    class Database{

        private $user ;
        private $host;
        private $pass;
        private $db;
    
        public function __construct()
        {
            $this->user = "root";
            $this->host = "localhost";
            $this->pass = "root";
            $this->db = "bibli_enligne";
        }
        public function connect()
        {
            try{
                $db = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db, $this->user, $this->pass);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $db;
            } catch(PDOException $e){
                echo $e;
                return $e;
            }
        }
    }

    class Auteur{

        protected $IDAuteur;
        private $Nom;
        private $prenom;
        private $biographie;

        public function __construct($Nom, $prenom, $biographie){
            $this->Nom = $Nom;
            $this->prenom = $prenom;
            $this->biographie = $biographie;
        }
        

        /// GETTERS - SETTERS
        public function getNom(){
            return $this->Nom;
        }
        public function getPrenom(){
            return $this->prenom;
        }
        public function getBiographie(){
            return $this->biographie;
        }
        public function setNom($Nom){
            $this->Nom = $Nom;
        }
        public function setPrenom($prenom){
            $this->prenom = $prenom;
        }
        public function setBiographie($biographie){
            $this->biographie = $biographie;
        }
        public function getIDAuteur(){
            return $this->IDAuteur;
        }
        public function setIDAuteur($IDAuteur){
            $this->IDAuteur = $IDAuteur;
        }


    }

    class Livre{

        private $IDlivre;
        private $titre;
        private $datedesortie;
        private $nbPage;
        private $IDAuteur;

        public function __construct($titre, $date, $nbPage, $IDAuteur){
            $this->titre = $titre;
            $this->datedesortie = $date;
            $this->nbPage = $nbPage;
            $this->IDAuteur = $IDAuteur;
        }


        /// GETTERS - SETTERS
        public function getIDlivre(){
            return $this->IDlivre;
        }
        public function getTitre(){
            return $this->titre;
        }
        public function getDate(){
            return $this->datedesortie;
        }
        public function getNbPage(){
            return $this->nbPage;
        }
        public function setIDlivre($IDlivre){
            $this->IDlivre = $IDlivre;
        }
        public function setTitre($titre){
            $this->titre = $titre;
        }
        public function setDate($date){
            $this->datedesortie = $date;
        }
        public function setNbPage($nbPage){
            $this->nbPage = $nbPage;
        }
        public function setIDAuteur($IDAuteur){
            $this->IDAuteur = $IDAuteur;
        }
        public function getIDAuteur(){
            return $this->IDAuteur;
        }


    }
    
    class Utilisateur{
        
        private $IDutilisateur;
        private $nom;
        private $prenom;
        private $email;

        public function __construct($nom, $prenom, $email){
            $this->nom = $nom;
            $this->prenom = $prenom;
            $this->email = $email;
        }


        /// GETTERS - SETTERS
        public function getNom(){
            return $this->nom;
        }
        public function getPrenom(){
            return $this->prenom;
        }
        public function getEmail(){
            return $this->email;
        }
        public function setNom($nom){
            $this->nom = $nom;
        }
        public function setPrenom($prenom){
            $this->prenom = $prenom;
        }
        public function setEmail($email){
            $this->email = $email;
        }
        public function getIDutilisateur(){
            return $this->IDutilisateur;
        }
        public function setIDutilisateur($IDutilisateur){
            $this->IDutilisateur = $IDutilisateur;
        }


    
    }
    class Emprunt{
        private $IDemprunt;
        private $IDlivre;
        private $dateEmprunt;
        private $dateRetour;
        private $IDutilisateur;

        /// constructor
        public function __construct($IDlivre, $dateEmprunt, $dateRetour, $IDutilisateur){
            $this->IDlivre = $IDlivre;
            $this->dateEmprunt = $dateEmprunt;
            $this->dateRetour = $dateRetour;
            $this->IDutilisateur = $IDutilisateur;

        }


        /// GETTERS - SETTERS
        public function getIDemprunt(){
            return $this->IDemprunt;
        }
        public function getIDlivre(){
            return $this->IDlivre;
        }
        public function getDateEmprunt(){
            return $this->dateEmprunt;
        }
        public function getDateRetour(){
            return $this->dateRetour;
        }
        public function setIDemprunt($IDemprunt){
            $this->IDemprunt = $IDemprunt;
        }
        public function setIDlivre($IDlivre){
            $this->IDlivre = $IDlivre;
        }
        public function setDateEmprunt($dateEmprunt){
            $this->dateEmprunt = $dateEmprunt;
        }
        public function setDateRetour($dateRetour){
            $this->dateRetour = $dateRetour;
        }
        public function setIDutilisateur($IDutilisateur){
            $this->IDutilisateur = $IDutilisateur;
        }
        public function getIDutilisateur(){
            return $this->IDutilisateur;
        }
    }

    class Bibliotheque{

        private $db;

        public function __construct($db){
            $this->db = $db;
        }
        //Ici nous avons nos fonctions ajouter pour la gestion de la base de donnée//

        public function ajouterAuteur(Auteur $auteur){
            $nom = $auteur->getNom();
            $prenom = $auteur->getPrenom();
            $biographie = $auteur->getBiographie();
            $stmt = ("INSERT INTO auteur (Nom, Prenom, Biographie) VALUES (:Nom, :Prenom, :Biographie)");
            $req = $this->db->prepare($stmt);
            $req->bindParam(':Nom', $nom);
            $req->bindParam(':Prenom', $prenom);
            $req->bindParam(':Biographie', $biographie);
            $req->execute();
            header("Location: index.php");
        }

        public function ajouterLivre(Livre $livre){
            $titre = $livre->getTitre();
            $date = $livre->getDate();
            $nbPage = $livre->getNbPage();
            $idAuteur = $livre->getIDAuteur();
            $stmt = ("INSERT INTO livre (Titre, DateDePublication, nbPages, IDAuteur) VALUES (:titre, :date, :nbPage, :idAuteur)");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':titre', $titre);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':nbPage', $nbPage);
            $stmt->bindParam(':idAuteur', $idAuteur);
            $stmt->execute();
            header("Location: index.php");

        }

        public function ajouterEmprunt(Emprunt $emprunt){
            $IDlivre = $emprunt->getIDlivre();
            $dateEmprunt = $emprunt->getDateEmprunt();
            $dateRetour = $emprunt->getDateRetour();
            $IDutilisateur = (int)$emprunt->getIDutilisateur();
            $sql = $this->db->query('SELECT idAuteur FROM livre WHERE ID = '. $IDlivre);
            $sql->execute();
            $idAuteur = $sql->fetch(PDO::FETCH_ASSOC);
            $idAuteur = $idAuteur['idAuteur'];
            $stmt = $this->db->prepare("INSERT INTO Emprunt (idLivre, date_emprunt, date_retour, idUtilisateur) VALUES (:idlivre, :dateEmprunt, :dateRetour, :idutilisateur)");
            $stmt->bindParam(':idlivre', $IDlivre);
            $stmt->bindParam(':dateEmprunt', $dateEmprunt);
            $stmt->bindParam(':dateRetour', $dateRetour);
            $stmt->bindParam(':idutilisateur', $IDutilisateur, PDO::PARAM_INT);
            $stmt->execute();
            header("Location: index.php");

        }

        public function ajouterUtilisateur(Utilisateur $utilisateur){
            $nom = $utilisateur->getNom();
            $prenom = $utilisateur->getPrenom();
            $email = $utilisateur->getEmail();
            $stmt = ("INSERT INTO Utilisateur (nom, prenom, email) VALUES (:nom, :prenom, :email)");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':nom', $nom);
            $stmt->bindParam(':prenom', $prenom);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            header("Location: index.php");
        }
        //Ici nous avons nos fonctions afficher pour la gestion de la base de donnée //

        public function afficherBibliothèque($date){
            $result = $this->db->query("SELECT * FROM livre");
        
            
            while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                echo "<tr> \n";
                echo "<td>".  $row["ID"]. "</td> \n";
                echo "<td>".  $row["titre"]. "</td> \n";
                echo "<td>".  $row["datedepublication"]. "</td> \n";
                echo "<td>".  $row["nbPages"]. "</td> \n";
                echo "<td>".  $row["idAuteur"]. "</td> \n";
            

                $sql1 = $this->db->prepare("SELECT COUNT(*) as count FROM Emprunt WHERE idLivre = :idLivre AND (date_retour = :date OR date_retour > :date)");
                $sql1->bindParam(':idLivre', $row["ID"]);
                $sql1->bindParam(':date', $date);
                $sql1->execute();
                $row1 = $sql1->fetch(PDO::FETCH_ASSOC);
                $dispo = $row1['count'] == 0;
            
                if ($dispo){
                    echo "<td> Oui </td> \n";
                } else {
                    echo "<td> Non </td> \n";
                }
            
                echo "<td> <form method='post' action='supprimer.php'> <input type='hidden' name='id' value=". $row["ID"] ."> <button class='smallbtn' name='SupprLivre' type='submit'><i class='fa-solid fa-rectangle-xmark'></i> </button></form> </td> \n";
                echo "</tr> \n";
            }
            

        }

        public function afficherAuteur(){
            $result = $this->db->query("SELECT * FROM auteur");
            while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                
                echo "<tr> \n";
                echo "<td>".  $row["ID"]. "</td> \n";
                echo "<td>".  $row["nom"]. "</td> \n";
                echo "<td>".  $row["prenom"]. "</td> \n";
                echo "<td>".  $row["biographie"]. "</td> \n";
                echo "<td> <form method='post' action='supprimer.php'> <input type='hidden' name='id' value=". $row["ID"] ."><button class='smallbtn' name='SupprAuteur' type='submit'><i class='fa-solid fa-rectangle-xmark'></i> </button></form> </td>\n";
                echo "</tr> \n";

                
            }
        }
        public function afficherEmprunt(){
            $sql1 = $this->db->query("SELECT * FROM Emprunt");
            while ($row = $sql1->fetch(PDO::FETCH_ASSOC)){
                $sql2 = $this->db->query("SELECT * FROM livre WHERE ID = ". $row["idLivre"]);
                $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
                $sql3 = $this->db->query("SELECT Nom FROM auteur WHERE ID = ". $row2["idAuteur"]);
                $row3 = $sql3->fetch(PDO::FETCH_ASSOC);
                echo "<tr> \n";
                echo "<td>".  $row["ID"]. "</td> \n";
                echo "<td>".  $row2["titre"]. "</td> \n";
                echo "<td>".  $row3["Nom"]. "</td> \n";
                echo "<td>".  $row["date_emprunt"]. "</td> \n";
                echo "<td>".  $row["date_retour"]. "</td> \n";
                echo "<td>".  $row["idUtilisateur"]. "</td> \n";
                echo "<td> <form method='post' action='supprimer.php'> <input type='hidden' name='id' value=". $row["ID"]."><button class='smallbtn' name='SupprEmprunt' type='submit'><i class='fa-solid fa-rectangle-xmark'></i> </button> </form> </td>\n";
                echo "</tr> \n";
            }
        }

        public function afficherAccEmprunt($date){
            $sql1 = $this->db->prepare("SELECT * FROM Emprunt WHERE date_retour = :date OR date_retour > :date");
            $sql1->bindParam(':date', $date);
            $sql1->execute();
            while ($row = $sql1->fetch(PDO::FETCH_ASSOC)){
                $sql2 = $this->db->query("SELECT * FROM livre WHERE ID = ". $row["idLivre"]);
                $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
                $sql3 = $this->db->query("SELECT Nom FROM auteur WHERE ID = ". $row2["idAuteur"]);
                $row3 = $sql3->fetch(PDO::FETCH_ASSOC);


                echo "<tr> \n";
                echo "<td>".  $row["ID"]. "</td> \n";
                echo "<td>".  $row2["titre"]. "</td> \n";
                echo "<td>".  $row3["Nom"]. "</td> \n";
                echo "<td>".  $row["date_emprunt"]. "</td> \n";
                echo "<td>".  $row["date_retour"]. "</td> \n";
                echo "<td>".  $row["idUtilisateur"]. "</td> \n";
                echo "<td> <form method='post' action='supprimer.php'> <input type='hidden' name='id' value=". $row["ID"]."><button class='smallbtn' name='SupprEmprunt' type='submit'><i class='fa-solid fa-rectangle-xmark'></i> </button> </form> </td>\n";
                echo "</tr> \n";
                
            }
        }


        
        public function afficherUtilisateur($date){
            $result = $this->db->query("SELECT * FROM Utilisateur");
            while ($row = $result->fetch(PDO::FETCH_ASSOC)){
                $sql = $this->db->prepare("SELECT COUNT(*) as bookCount FROM emprunt WHERE idUtilisateur = :userID AND (date_retour = :date OR date_retour > :date)");
                $sql->bindParam(':userID', $row["ID"]);
                $sql->bindParam(':date', $date);
                $sql->execute();
                
                $bookCount = $sql->fetch(PDO::FETCH_ASSOC)['bookCount'];
                
                echo "<tr> \n";
                echo "<td>".  $row["ID"]. "</td> \n";
                echo "<td>".  $row["nom"]. "</td> \n";
                echo "<td>".  $row["prenom"]. "</td> \n";
                echo "<td>".  $row["email"]. "</td> \n";
                
                if ($bookCount > 0) {
                    echo "<td> <button class='searchbtn' style='width = 100%;' onclick='afficherUtilisateurEmprunts(".$row["ID"].")'><i class='fas fa-search'></i></button></td>\n";
                } else {
                    echo "<td> Aucun livre emprunté </td>";
                }
                
                echo "<td> <form method='post' action='supprimer.php'> <input type='hidden' name='id' value=". $row["ID"] ."><button class='smallbtn' name='SupprUtilisateur' type='submit'><i class='fa-solid fa-rectangle-xmark'></i> </button></form> </td>\n";
                echo "</tr> \n";
            }

            
        }

        public function afficherUtilisateurEmprunts($date){
            $sql1 = $this->db->prepare("SELECT * FROM livre l INNER JOIN Emprunt e ON e.idLivre = l.ID WHERE e.date_retour = :date OR date_retour > :date");
                $sql1->bindParam(':date', $date);
                $sql1->execute();
            
            while ($row = $sql1->fetch(PDO::FETCH_ASSOC)){
                if ($row["idUtilisateur"] == $_GET["uid"]){
                    $sql2 = $this->db->prepare("SELECT Nom FROM Utilisateur WHERE ID = :id");
                    $sql2->bindParam(':id', $row["idUtilisateur"]);
                    $sql2->execute();
                    $row2 = $sql2->fetchall(PDO::FETCH_ASSOC);
                    echo "<h3>Liste des livres empruntés par ". $row2[0]["Nom"] ."</h3> \n";
                    echo "<table>\n";
                    echo "<thead>\n";
                    echo "<tr>\n";
                    echo "<th>ID</th>\n";
                    echo "<th>Titre</th>\n";
                    echo "<th>Date de Sortie</th>\n";
                    echo "<th>Nombre de Pages</th>\n";
                    echo "<th>ID Auteur</th>\n";
                    echo "</tr>\n";
                    echo "</thead>\n";
                    echo "<tr> \n";
                    echo "<td>".  $row["ID"]. "</td> \n";
                    echo "<td>".  $row["titre"]. "</td> \n";
                    echo "<td>".  $row["datedepublication"]. "</td> \n";
                    echo "<td>".  $row["nbPages"]. "</td> \n";
                    echo "<td>".  $row["idAuteur"]. "</td \n>";
                    echo "</tr> \n";
                } else echo "<script> document.getElementById('form').style.display = 'none'; </script> ";
            

                
            }
        }
        //Ici nous avons nos fonctions supprimer pour la gestion de la base de donnée //

        public function supprimerLivre($id){
            $stmt = ("DELETE FROM livre WHERE ID = :id");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            header("Location: index.php");
        }
        public function supprimerAuteur($id){
            $stmt = ("DELETE FROM auteur WHERE ID = :id");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            header("Location: index.php");
        }
        public function supprimerEmprunt($id){
            $stmt = ("DELETE FROM emprunt WHERE ID = :id");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            header("Location: index.php");
        }
        public function supprimerUtilisateur($id){
            $stmt = ("DELETE FROM utilisateur WHERE ID = :id");
            $stmt = $this->db->prepare($stmt);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            header("Location: index.php");
        }

    }   

    $db = new Database();
    $db = $db->connect();
    $biblio = new Bibliotheque($db);
    $date = date('Y-m-d');
?>