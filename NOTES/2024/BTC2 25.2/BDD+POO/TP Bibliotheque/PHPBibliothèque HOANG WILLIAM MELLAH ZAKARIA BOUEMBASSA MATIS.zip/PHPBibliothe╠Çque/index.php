<?php
//création de notre tableau avec nos input//
    require 'classe.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div id="content">
        <h2>Bienvenue dans la bibliothèque !</h2>
        <button class="button-menu" onclick="afficherBiblio()"> Afficher Bibliothèque</button>
        <button class="button-menu" onclick="afficherEmprunt()"> Afficher Emprunts</button>
        <button class="button-menu" onclick="afficherAuteur()"> Afficher Liste Auteurs</button>
        <button class="button-menu" onclick="afficherUtilisateur()"> Afficher Liste Utilisateurs</button>
    <?php
        echo "<h3 class='date'> $date </h3>";
    ?>
    <div id="biblio">
        <h3>Bibliothèque</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Date de Sortie</th>
                    <th>Nombre de Pages</th>
                    <th>ID Auteur</th>
                    <th>Disponible</th>
                </tr>
            </thead>
            <tbody>
                    <?php $biblio->afficherBibliothèque($date); ?>
                    
            </tbody>    
        </table>
        <h3>Ajouter un livre</h3>
        <form method="post" action="formulaire.php">
            <label for="titre">Titre</label>
            <input type="text" name="titre" id="titre">
            <label for="datedepublication">Date de publication</label>
            <input type="date" name="datedepublication" id="datedepublication">
            <label for="nbPages">Nombre de Pages</label>
            <input type="number" name="nbPages" id="nbPages">
            <label for="idAuteur">ID Auteur</label>
            <input type="number" name="idAuteur" id="idAuteur">
            <input type="submit" name="AjouterLivre" value="Ajouter un Livre">
        </form>

    </div>
        <div id="emprunt" style="display: none;">
        <h3>Emprunts actuels</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Date de l'emprunt</th>
                    <th>Date de retour</th>
                    <th>ID Utilisateur</th>
                </tr>
            </thead>
            <tbody>
                    <?php $biblio->afficherAccEmprunt($date); ?>
                    
            </tbody>    
        </table>
        <h3>Historique des Emprunts</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Auteur</th>
                    <th>Date de l'emprunt</th>
                    <th>Date de retour</th>
                    <th>ID Utilisateur</th>
                </tr>
            </thead>
            <tbody>
                    <?php $biblio->afficherEmprunt(); ?>
                    
            </tbody>    
        </table>
        <h3>Ajouter un emprunt</h3>
        <form method="post" action="formulaire.php">
            <label for="idLivre">ID Livre</label>
            <input type="number" name="idLivre" id="idLivre">
            <label for="dateEmprunt">Date de l'emprunt</label>
            <input type="date" name="dateEmprunt" id="dateEmprunt">
            <label for="dateRetour">Date de retour</label>
            <input type="date" name="dateRetour" id="dateRetour">
            <label for="idUtilisateur">ID Utilisateur</label>
            <input type="number" name="idUtilisateur" id="idUtilisateur">
            <input type="submit" name="AjouterEmprunt"value="Ajouter un Emprunt">
            
        </form>
    </div>
        <div id="auteur" style="display: none;">
        <h3>Auteurs</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Biographie</th>
                </tr>
            </thead>
            <tbody>
                    <?php $biblio->afficherAuteur(); ?>
                    
            </tbody>    
        </table>
        <h3>Ajouter un auteur</h3>
        <form method="post" action="formulaire.php">
            <label for="nom">Nom</label>
            <input type="text" name="nom" id="nom">
            <label for="prenom">Prenom</label>
            <input type="text" name="prenom" id="prenom">
            <label for="biographie">Biographie</label>
            <input type="text" name="biographie" id="biographie">
            <input type="submit" name="AjouterAuteur" value="Ajouter un Auteur">
        </form>
    </div>
        <div id="utilisateur" style="display: none;">
        <h3>Utilisateurs</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Email</th>
                    <th>Voir les livres empruntés</th>
                </tr>
            </thead>
            <tbody>
                    <?php $biblio->afficherUtilisateur($date);?>
                    
            </tbody>    
        </table>
        <h3>Ajouter un utilisateur</h3>
        <form name="form"method="post" action="formulaire.php">
            <label for="nom">Nom</label>
            <input type="text" name="nom" id="nom">
            <label for="prenom">Prenom</label>
            <input type="text" name="prenom" id="prenom">
            <label for="email">Email</label>
            <input type="text" name="email" id="email">
            <input type="submit" name="AjouterUtilisateur" value="Ajouter un Utilisateur">
        </form>
        </div>
        <div id="utilisateurlivre" style="display: none">
        <div id="form">
            <h3>Liste des livres empruntés</h3>
            <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Date de Sortie</th>
                    <th>Nombre de Pages</th>
                    <th>ID Auteur</th>
                </tr>
            </thead>
        </div>
            <tbody>
                    <?php $biblio->afficherUtilisateurEmprunts($date); ?>
                    
            </tbody>    
        </table>
        </div>

    </div>
    
</body>
<script src="https://kit.fontawesome.com/641d29b2c0.js" crossorigin="anonymous"></script>
<script src="script.js"></script>
</html>