<?php
require "classes.php";

$addLivre = new Livre();

if (isset($_POST["submit"])) {
    $addLivre->addLivre($_POST["titre"], $_POST["date"], $_POST["page"], $_POST["auteur"]);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Ajouter un livre</title>
</head>

<body>
    <?php
    require "header.php";
    ?>

    <div class='boardot2'>
        <h2>Liste des livres</h2>
        <p>Avant de rajouter un livre, verifier que son auteur existe (Page auteur). Sinon rajouter un nouvel auteur </p>
        <table class='boardo2'>
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Date de publication</th>
                    <th>Nombre de pages</th>
                    <th>Nom de l'auteur</th>
                    <th>Prénom de l'auteur</th>
                </tr>
            </thead>
            <?php
            $livre = new livre();
            $livre->displayLivre();
            ?>
        </table>
    </div>

    <br>
    <div class="login-box">
        <h1>Ajouter un livre :</h1>

        <form method="POST">
            <div class="user-box">
                <input type="text" name="titre" placeholder="Titre" required>
                <label for="nom">Titre du livre</label>
            </div>
            <div class="user-box">
                <input type="date" name="date" placeholder="date" required>
                <label for="prenom">______________Date de publication</label>
            </div>
            <div class="user-box">
                <input type="number" name="page" placeholder="Nombre de pages" min="1" required>
                <label for="nombredepage">Nombre de pages</label>
            </div>
            <div class="user-box">
                <input type="text" name="auteur" placeholder="Nom de l'auteur" required>
                <label for="bio">Nom de l'auteur</label>
            </div>
            <br>

            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>
    <img class="img4" src="img/library.png" alt="">
    <?php
    require "footer.php";
    ?>
</body>

</html>