<?php
require "classes.php";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Gestion Bibiliothèque</title>
</head>

<body>
    <?php
    require "header.php";
    ?>
    <h2>Liste des livres disponibles</h2>
    <div class='boardot'>
        <table class='boardo'>
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Date de publication</th>
                    <th>Nombre de pages</th>
                    <th>Nom de l'auteur</th>
                    <th>Options</th>
                    <th>Disponibilité</th>

                </tr>
            </thead>
            <?php
            $noEmprunt = new Emprunt();
            $noEmprunt->displayLivreNoEmprunt();
            ?>
        </table>
    </div>
    <h2>Liste des livres empruntés</h2>
    <div class='boardot'>
        <table class='boardo'>
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Emprunté par</th>
                    <th>Date d'emprunt</th>
                    <th>Disponibilité</th>
                </tr>
            </thead>
            <?php
            $emprunt = new Emprunt();
            $emprunt->displayLivreEmprunt();
            ?>
        </table>
    </div>
    <img class="img3" src="img/books.png" alt="">
    <?php
    require "footer.php";
    ?>
</body>

</html>