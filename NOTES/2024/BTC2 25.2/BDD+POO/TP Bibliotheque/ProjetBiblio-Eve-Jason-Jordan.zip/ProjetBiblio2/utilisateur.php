<?php
require "classes.php";

$addUtilisateur = new Utilisateur();

if (isset($_POST["submit"])) {
    $addUtilisateur->addUtilisateur($_POST["nom"], $_POST["prenom"], $_POST["email"]);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Ajouter un utilisateur</title>
</head>

<body>
    <?php
    require "header.php";
    ?>

    <div class='boardot2'>
        <h2>Liste des utilisateurs</h2>
        <table class='boardo2'>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                </tr>
            </thead>
            <?php
            $utilisateur = new Utilisateur();
            $utilisateur->displayUtilisateur();
            ?>
        </table>
    </div>
    <br>

    <div class="login-box">
        <h1>Ajout utilisateur</h1>
        <form method="POST">
            <div class="user-box">
                <input type="text" name="nom" placeholder="Nom" required>
                <label for="nom">Nom de l'utilisateur : </label>
            </div>
            <div class="user-box">
                <input type="text" name="prenom" placeholder="Prénom" required>
                <label for="prenom">Prénom de l'utilisateur</label>
            </div>

            <div class="user-box">
                <input type="email" name="email" placeholder="Email" required>
                <label for="email">Email</label>
            </div>
            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>
    <img class="img1" src="img/add-group.png" alt="">

    <?php
    require "footer.php";
    ?>
</body>

</html>