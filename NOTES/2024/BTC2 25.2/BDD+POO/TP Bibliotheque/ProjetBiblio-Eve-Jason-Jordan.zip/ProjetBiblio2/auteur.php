<?php
require "classes.php";

$addAuteur = new Auteur();

if (isset($_POST["submit"])) {
    $addAuteur->addAuteur($_POST["nom"], $_POST["prenom"], $_POST["bio"]);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Ajouter un auteur</title>
</head>

<body>
    <?php
    require "header.php";
    ?>
    <div class='boardot2'>
        <h2>Liste des auteurs</h2>
        <table class='boardo2'>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Biographie</th>
                </tr>
            </thead>
            <?php
            $auteur = new Auteur();
            $auteur->displayAuteur();
            ?>
        </table>
    </div>
    <br>
    <div class="login-box">
        <h1>Ajout auteur</h1>
        <form method="POST">
            <div class="user-box">
                <input type="text" name="nom" placeholder="Nom" required>
                <label for="nom">Nom de l'auteur</label>
            </div>
            <div class="user-box">
                <input type="text" name="prenom" placeholder="Prénom" required>
                <label for="prenom">Prénom de l'auteur</label>
            </div>
            <br>
            <div class="user-box">

                <!-- <input type="textarea" name="bio" placeholder="biographie" required> -->
                <textarea name="bio" placeholder="biographie" required rows="10" cols="35"></textarea><br>
                <label for="bio">Biographie</label>
            </div>


            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>
    <img class="img0" src="img/writer.png" alt="">

    <?php
    require "footer.php";
    ?>
</body>

</html>