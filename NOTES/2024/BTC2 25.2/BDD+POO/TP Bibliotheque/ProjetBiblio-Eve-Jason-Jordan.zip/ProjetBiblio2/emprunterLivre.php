<?php
require "classes.php";

$emprunterLivre = new Emprunt();

if (isset($_GET["idLivre"])) {
    if (isset($_POST["submit"])) {
        $emprunterLivre->emprunterUnLivre($_GET["idLivre"], $_POST["email"]);
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Emprunter un livre</title>
</head>

<body>
    <?php
    require "header.php";
    ?>
    <div class="login-box">
        <h1>Formulaire d'emprunt</h1>
        <form method="POST">
            <div class="user-box">
                <input type="email" name="email" placeholder="Email" required>
                <label for="email">Saisir votre email</label>
            </div>
            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>
    <img class="img2" src="img/return.png" alt="">
    <?php
    require "footer.php";
    ?>
</body>

</html>