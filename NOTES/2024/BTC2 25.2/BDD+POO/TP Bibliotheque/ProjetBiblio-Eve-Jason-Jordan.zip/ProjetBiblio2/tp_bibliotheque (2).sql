-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 23 jan. 2024 à 11:44
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tp_bibliotheque`
--
DROP DATABASE IF EXISTS tp_bibliotheque;
CREATE DATABASE tp_bibliotheque;
USE tp_bibliotheque;
-- --------------------------------------------------------

--
-- Structure de la table `auteur`
--

DROP TABLE IF EXISTS `auteur`;
CREATE TABLE IF NOT EXISTS `auteur` (
  `id_auteur` int NOT NULL AUTO_INCREMENT,
  `nom_auteur` varchar(50) DEFAULT NULL,
  `prenom_auteur` varchar(50) DEFAULT NULL,
  `biographie` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_auteur`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `auteur`
--

INSERT INTO `auteur` (`id_auteur`, `nom_auteur`, `prenom_auteur`, `biographie`) VALUES
(1, ' Márquez', 'Gabriel', '(1927-2014):\r\nÉcrivain colombien mondialement connu pour son chef-d\'œuvre \"Cent ans de solitude\"'),
(2, 'Murakami', 'Haruki', '(né en 1949):\r\nAuteur japonais contemporain célèbre pour ses œuvres mêlant fantaisie et fiction'),
(3, 'Adichie', 'Ngozi', '(née en 1977):\r\nÉcrivaine nigériane acclamée pour ses romans, dont \"L\'hibiscus pourpre\" et \"American'),
(4, 'Borges', 'Jorge', '(1899-1986):\r\nÉcrivain argentin renommé pour ses œuvres fantastiques telle que \"Fictions\"');

-- --------------------------------------------------------

--
-- Structure de la table `emprunt`
--

DROP TABLE IF EXISTS `emprunt`;
CREATE TABLE IF NOT EXISTS `emprunt` (
  `id_emprunt` int NOT NULL AUTO_INCREMENT,
  `id_livre` int DEFAULT NULL,
  `id_utilisateur` int DEFAULT NULL,
  `date_emprunt` date DEFAULT NULL,
  `date_retour` date DEFAULT NULL,
  PRIMARY KEY (`id_emprunt`),
  KEY `id_livre` (`id_livre`),
  KEY `id_utilisateur` (`id_utilisateur`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `emprunt`
--

INSERT INTO `emprunt` (`id_emprunt`, `id_livre`, `id_utilisateur`, `date_emprunt`, `date_retour`) VALUES
(1, 1, 2, '2024-05-21', '2024-01-23'),
(2, 4, 4, '2024-01-23', '2024-01-23'),
(3, 5, 4, '2024-01-23', '2024-01-23'),
(4, 4, 4, '2024-01-23', '2024-01-23'),
(5, 8, 4, '2024-01-23', '2024-01-23'),
(6, 4, 4, '2024-01-23', '2024-01-23'),
(7, 4, 4, '2024-01-23', '2024-01-23');

-- --------------------------------------------------------

--
-- Structure de la table `livre`
--

DROP TABLE IF EXISTS `livre`;
CREATE TABLE IF NOT EXISTS `livre` (
  `id_livre` int NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) DEFAULT NULL,
  `date_publication` date DEFAULT NULL,
  `nbr_pages` int DEFAULT NULL,
  `id_auteur` int DEFAULT NULL,
  PRIMARY KEY (`id_livre`),
  KEY `id_auteur` (`id_auteur`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `livre`
--

INSERT INTO `livre` (`id_livre`, `titre`, `date_publication`, `nbr_pages`, `id_auteur`) VALUES
(1, 'L\'Ombre du Saphir', '2024-01-01', 258, 2),
(2, 'Chroniques de l\'Aurore Perdue', '2024-02-02', 585, 3),
(3, 'Cent ans de solitude', '2024-03-03', 897, 1),
(4, 'Les Échos de la Cité Interdite', '2024-04-04', 66, 2),
(8, 'Les Murmures du Labyrinthe', '2024-01-19', 41, 1);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_utilisateur` int NOT NULL AUTO_INCREMENT,
  `nom_utilisateur` varchar(50) DEFAULT NULL,
  `prenom_utilisateur` varchar(50) DEFAULT NULL,
  `email_utilisateur` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `nom_utilisateur`, `prenom_utilisateur`, `email_utilisateur`) VALUES
(1, 'nom_utilisateur1', 'prenom_utilisateur1', 'utilisateur1@test.fr'),
(2, 'nom_utilisateur2', 'prenom_utilisateur2', 'utilisateur2@test.fr'),
(3, 'nom_utilisateur3', 'prenom_utilisateur3', 'utilisateur3@test.fr'),
(4, 'eve', 'eve', 'eve@eve.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
