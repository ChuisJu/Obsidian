<?php
require "classes.php";
$retourLivre = new Emprunt();

if (isset($_GET["idLivre"])) {
    $retourLivre->retourLivre($_GET["idLivre"]);
    header("Location: index.php");
}
