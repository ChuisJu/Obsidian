<?php
require "classes.php";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/mainn.css">
    <title>Liste personnelle</title>
</head>

<body>
    <?php
    require "header.php";
    ?>
    <div class="login-box">
        <h1>Formulaire de retour</h1>
        <form method="POST">
            <div class="user-box">
                <input type="email" name="email" placeholder="Email" required>
                <label for="email">Saisir votre email</label>
            </div>
            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>

    <div class='boardot2'>
        <h2>Liste des livres empruntés</h2>
        <table class='boardo2'>
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php
            $afficherListe = new Emprunt();

            if (isset($_POST["submit"])) {
                $afficherListe->displayListePersonnelle($_POST["email"]);
            }
            ?>
        </table>
    </div>
    <img class="img4" src="img/returnbook.png" alt="">
    <?php
    require "footer.php";
    ?>
</body>

</html>