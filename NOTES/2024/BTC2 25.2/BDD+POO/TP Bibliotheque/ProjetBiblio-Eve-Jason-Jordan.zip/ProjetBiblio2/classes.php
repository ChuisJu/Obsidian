<?php

class Database
{
    public $host = "localhost";
    public $user = "root";
    public $name = "tp_bibliotheque";
    public $bdd;

    public function __construct()
    {
        $this->bdd = new PDO("mysql:host=$this->host;dbname=$this->name", $this->user);
    }
}

//Classe qui permet de gérer les livres
class Livre extends Database
{
    //Fonction qui permet d'ajouter les informations d'un livre dans la base de données
    public function addLivre($titreLivre, $datePublication, $nbrPages, $nomAuteur)
    {
        if (!empty($titreLivre) && !empty($datePublication) && !empty($nbrPages) && !empty($nomAuteur)) {
            $query1 = $this->bdd->prepare("SELECT id_auteur FROM auteur WHERE nom_auteur = :nomAuteur");
            $query1->bindParam(":nomAuteur", $nomAuteur);
            $query1->execute();
            $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data1 as $row) {
                $idAuteur = $row["id_auteur"];
            }

            $query2 = $this->bdd->prepare("INSERT INTO livre(titre, date_publication, nbr_pages, id_auteur) VALUES (:titre, :datePublication, :nbrPages, :idAuteur)");
            $query2->bindParam(":titre", $titreLivre);
            $query2->bindParam(":datePublication", $datePublication);
            $query2->bindParam(":nbrPages", $nbrPages);
            $query2->bindParam(":idAuteur", $idAuteur);
            $query2->execute();
        }
    }

    //Fonction qui permet d'afficher les informations de tous livres
    public function displayLivre()
    {
        $query1 = $this->bdd->prepare("SELECT titre, date_publication, nbr_pages, nom_auteur, prenom_auteur FROM livre l INNER JOIN auteur a ON l.id_auteur = a.id_auteur ORDER BY l.id_livre");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "<tr>
            <td>{$row['titre']}</td>
            <td>{$row['date_publication']}</td>
            <td>{$row['nbr_pages']}</td>
            <td>{$row['nom_auteur']}</td>
            <td>{$row['prenom_auteur']}</td>
            </tr>";
        }
    }
}

//Classe qui permet de gérer les auteurs
class Auteur extends Database
{
    //Fonction qui permet d'ajouter les informations d'un auteur dans la base de données
    public function addAuteur($nomAuteur, $prenomAuteur, $biographie)
    {
        if (!empty($nomAuteur) && !empty($prenomAuteur) && !empty($biographie)) {
            $query1 = $this->bdd->prepare("INSERT INTO auteur(nom_auteur, prenom_auteur, biographie) VALUES (:nomAuteur, :prenomAuteur, :biographie)");
            $query1->bindParam(":nomAuteur", $nomAuteur);
            $query1->bindParam(":prenomAuteur", $prenomAuteur);
            $query1->bindParam(":biographie", $biographie);
            $query1->execute();
        }
    }

    //Fonction qui permet d'afficher les informations de tous les auteurs
    public function displayAuteur()
    {
        $query1 = $this->bdd->prepare("SELECT nom_auteur, prenom_auteur, biographie FROM auteur");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "<tr>
            <td>{$row['nom_auteur']}</td>
            <td>{$row['prenom_auteur']}</td>
            <td>{$row['biographie']}</td>
            </tr>";
        }
    }
}

//Classe qui permet de gérer les utilisateurs
class Utilisateur extends Database
{
    //Fonction qui permet d'ajouter les informations d'un utilisateur dans la base de données
    public function addUtilisateur($nomUtilisateur, $prenomUtilisateur, $emailUtilisateur)
    {
        if (!empty($nomUtilisateur) && !empty($prenomUtilisateur) && !empty($emailUtilisateur)) {
            $query1 = $this->bdd->prepare("INSERT INTO utilisateur(nom_utilisateur, prenom_utilisateur, email_utilisateur) VALUES (:nomUtilisateur, :prenomUtilisateur, :emailUtilisateur)");
            $query1->bindParam(":nomUtilisateur", $nomUtilisateur);
            $query1->bindParam(":prenomUtilisateur", $prenomUtilisateur);
            $query1->bindParam(":emailUtilisateur", $emailUtilisateur);
            $query1->execute();
        }
    }

    //Fonction qui permet d'afficher les informations de tous les utilisateurs
    public function displayUtilisateur()
    {
        $query1 = $this->bdd->prepare("SELECT nom_utilisateur, prenom_utilisateur, email_utilisateur FROM utilisateur");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "<tr>
            <td>{$row['nom_utilisateur']}</td>
            <td>{$row['prenom_utilisateur']}</td>
            <td>{$row['email_utilisateur']}</td>
            </tr>";
        }
    }
}

//Classe qui permet de gérer les emprunts
class Emprunt extends Database
{
    //Fonction qui permet d'afficher la liste des livres déjà empruntés
    public function displayLivreEmprunt()
    {
        $query1 = $this->bdd->prepare("SELECT e.id_livre, titre, prenom_utilisateur, date_emprunt FROM emprunt e INNER JOIN livre l ON e.id_livre = l.id_livre INNER JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur WHERE date_retour IS NULL");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "<tr>
                <td>{$row['titre']}</td>
                <td>{$row['prenom_utilisateur']}</td>
                <td>{$row['date_emprunt']}</td>
                <td><img class='check' src='img/cancel.png' alt=''></td>
                </tr>";
        }
    }

    //Fonction qui permet d'afficher la liste des livres qui ne sont pas empruntés
    public function displayLivreNoEmprunt()
    {
        $query1 = $this->bdd->prepare("SELECT * FROM livre l INNER JOIN auteur a ON l.id_auteur = a.id_auteur WHERE l.id_livre NOT IN (SELECT id_livre FROM emprunt WHERE date_retour IS NULL)");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idLivre = $row["id_livre"];

            $query2 = $this->bdd->prepare("SELECT * FROM livre l INNER JOIN auteur a ON l.id_auteur = a.id_auteur WHERE id_livre = :idLivre");
            $query2->bindParam(":idLivre", $idLivre);
            $query2->execute();
            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                echo "<tr>
                <td>{$row['titre']}</td>
                <td>{$row['date_publication']}</td>
                <td>{$row['nbr_pages']}</td>
                <td>{$row['nom_auteur']}</td>
                <td><a href='emprunterLivre.php?idLivre={$row["id_livre"]}'>Emprunter</a></td>
                <td><img class='check' src='img/checked.png' alt=''></td>
                </tr>";
            }
        }
    }

    //Fonction qui permet d'ajouter un emprunt dans la base de données
    public function emprunterUnLivre($idLivre, $emailUtilisateur)
    {
        $query1 = $this->bdd->prepare("SELECT id_utilisateur FROM utilisateur WHERE email_utilisateur = :emailUtilisateur");
        $query1->bindParam(":emailUtilisateur", $emailUtilisateur);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idUtilisateur = $row["id_utilisateur"];
            $query2 = $this->bdd->prepare("INSERT INTO emprunt(id_livre, id_utilisateur, date_emprunt) VALUES (:idLivre, :idUtilisateur, NOW())");
            $query2->bindParam(":idLivre", $idLivre);
            $query2->bindParam(":idUtilisateur", $idUtilisateur);
            $query2->execute();
        }
        header("Location: index.php");
    }

    //Fonction qui permet d'afficher la liste de livre(s) emprunté(s) par un utilisateur
    public function displayListePersonnelle($emailUtilisateur)
    {
        $query1 = $this->bdd->prepare("SELECT l.titre, l.id_livre FROM livre l INNER JOIN emprunt e ON l.id_livre = e.id_livre AND date_retour IS NULL INNER JOIN utilisateur u ON e.id_utilisateur = u.id_utilisateur INNER JOIN auteur a ON l.id_auteur = a.id_auteur WHERE u.email_utilisateur = :emailUtilisateur");
        $query1->bindParam(":emailUtilisateur", $emailUtilisateur);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "<tr>
            <td>{$row['titre']}</td>
            <td><a href='retour.php?idLivre={$row["id_livre"]}'>Retourner</a></td>
            </tr>";
        }
    }

    //Fonction qui permet d'ajouter une date de retour dans la colonne date_retour de la table emprunt
    public function retourLivre($idLivre)
    {
        $query1 = $this->bdd->prepare("UPDATE emprunt SET date_retour = NOW() WHERE id_livre = :idLivre AND date_retour IS NULL");
        $query1->bindParam(":idLivre", $idLivre);
        $query1->execute();
    }
}
