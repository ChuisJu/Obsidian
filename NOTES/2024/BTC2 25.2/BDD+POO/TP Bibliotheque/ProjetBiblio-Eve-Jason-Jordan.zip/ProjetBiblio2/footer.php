<footer class="footer">
    <div class="wrapper">
        <svg>
            <text x="50%" y="50%" dy=".35em" text-anchor="middle">
                E-J-J ProjEcT
            </text>
        </svg>
    </div>
    <p>Copyright © 2024 Projet Base de données - Tous droits réservés.</p>
</footer>