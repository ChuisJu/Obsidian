<header>
    <nav id='menu'>
        <ul>
            <li>
                <h3></h3>
            </li>
            <li><a href="index.php">Accueil</a></li>
            <li><a href="auteur.php">Auteur</a></li>
            <li><a href="livre.php">Livre</a></li>
            <li><a href="utilisateur.php">Utilisateur</a></li>
            <li><a href="listeLivre.php">Retourner un livre</a></li>
        </ul>
    </nav>
</header>