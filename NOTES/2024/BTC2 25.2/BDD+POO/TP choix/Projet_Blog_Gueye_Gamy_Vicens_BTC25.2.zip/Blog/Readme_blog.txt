Manuel utilisation Blog /

Site :
Ce site vous permettra de lire créer modifier et supprimer des articles.  Sur la page principale, vous trouverez un article à la une, lisible par tous les utilisateurs même sans se connecter ainsi que plusieurs autres articles qui, en revanche nécessitent une connexion/inscription au site pour pouvoir être lus. 
 Le nom du blog est un lien permettant de revenir à la page d’accueil. 
En vous connectant avec votre compte : 
Identifiant : admin
Mot de passe : admin
Vous arriverez sur votre page de création d’article. Vous aurez juste à remplir le formulaire et/ou appuyer sur les boutons pour ajouter/modifier/supprimer un article.
