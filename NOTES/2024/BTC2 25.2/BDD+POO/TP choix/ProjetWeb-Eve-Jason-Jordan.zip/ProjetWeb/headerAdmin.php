<header>
    <img class='logou' src='img/logo.png' alt=''>
    <nav class="allNav">
        <ul class="navlinks">

            <li><a href="admin.php" class="link linki">Accueil</a></li>
            <li><a href="adminPageArticle.php" class="link linki">Gérer articles</a></li>
            <li><a href="adminPageUser.php" class="link linki">Gérer utilisateurs</a></li>

        </ul>
    </nav>
    <a href="disconnect.php" class="disconnect link">Déconnexion</a>
</header>