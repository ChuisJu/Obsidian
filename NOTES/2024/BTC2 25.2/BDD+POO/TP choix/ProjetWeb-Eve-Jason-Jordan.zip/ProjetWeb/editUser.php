<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

if ($_SESSION["role"] != 0) {
    header("Location: accessDenied.php");
}

if (isset($_POST["submitpseudo"])) {
    $editPseudo = new Utilisateur();
    $editPseudo->editPseudo($_POST["newpseudo"], $_GET["idUser"]);
}

if (isset($_POST["submitemail"])) {
    $editPseudo = new Utilisateur();
    $editPseudo->editEmail($_POST["newemail"], $_GET["idUser"]);
}

if (isset($_POST["submitpassword"])) {
    $editPseudo = new Utilisateur();
    $editPseudo->editPassword($_POST["newpassword"], $_POST["confirmnewpassword"], $_GET["idUser"]);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Modifier utilisateur</title>
</head>

<body>
    <?php
    require "headerAdmin.php";
    ?>
    <h2>Modifier utilisateur :</h2>

    <form method="POST"><b>Modifier pseudo : </b>
        <br><br>
        <label>Nouveau pseudo : </label>
        <br>
        <input type="text" name="newpseudo" placeholder="Nouveau pseudo">
        <br><br>
        <input type="submit" name="submitpseudo" value="Valider">
    </form>
    <br><br>
    <form method="POST"><b>Modifier email : </b>
        <br><br>
        <label>Nouvel email : </label>
        <br>
        <input type="text" name="newemail" placeholder="Nouvel email">
        <br><br>
        <input type="submit" name="submitemail" value="Valider">
    </form>
    <br><br>
    <form method="POST"><b>Modifier mot de passe :</b>
        <br><br>
        <label>Nouveau mot de passe : </label>
        <br>
        <input type="password" name="newpassword" placeholder="Nouveau mot de passe">
        <br><br>
        <label>Confirmer nouveau mot de passe : </label>
        <br>
        <input type="password" name="confirmnewpassword" placeholder="Confirmer nouveau mot de passe">
        <br><br>
        <input type="submit" name="submitpassword" value="Valider">
    </form>
    <br><br>

    <?php
    require "footer.php";
    ?>
</body>

</html>