<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

$idArticle = $_GET["idArticle"];
$idUser = $_SESSION["id"];


if (isset($_POST["submit"])) {
    $addCommentaire = new Commentaire();
    $addCommentaire->addCommentaire($_POST["comment"], $idArticle, $idUser);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Ajouter un commentaire</title>
</head>

<body>
    <?php
    if ($_SESSION["role"] == 0) {
        require "headerAdmin.php";
    }
    if ($_SESSION["role"] == 1) {
        require "headerUser.php";
    }
    ?>

    <form method="POST">
        <label for="comment">Votre commentaire</label>
        <textarea name="comment" cols="35" rows="10"></textarea>
        <input type="submit" name="submit">
    </form>

    <?php
    require "footer.php";
    ?>
</body>

</html>