<?php
require "classes.php";

if (!empty($_SESSION["id"])) {
    if ($_SESSION["role"] == 0) {
        header("Location: admin.php");
    } elseif ($_SESSION["role"] == 1) {
        header("Location: index.php");
    }
}

if (isset($_POST["submit"])) {
    $register = new Authentification();
    $register->registration($_POST["pseudo"], $_POST["email"], $_POST["password"], $_POST["confirmpassword"]);
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Inscription</title>
</head>

<body>
    <?php
    require "headerOffline.php";
    ?>

    <div class="login-box">

        <h1>Inscription</h1>
        <form method="POST">
            <div class="user-box">
                <input type="text" name="pseudo" placeholder="Pseudo" required>
                <label for="pseudo">Votre pseudo : </label>
            </div>

            <div class="user-box">
                <input type="mail" name="email" placeholder="Email" required>
                <label for="mail">Votre email : </label>
            </div>
            <div class="user-box">
                <input type="password" name="password" placeholder="Mot de passe" required>
                <label for="password">Votre mot de passe : </label>
            </div>
            <div class="user-box">
                <input type="password" name="confirmpassword" placeholder="Confirmer mot de passe" required>
                <label for="confirmpassword">Confirmer votre mot de passe : </label>
            </div>

            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>


    <?php
    require "footer.php";
    ?>
</body>

</html>