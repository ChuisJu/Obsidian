<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

if ($_SESSION["role"] != 0) {
    header("Location: accessDenied.php");
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Accueil Admin</title>
</head>

<body>
    <?php
    require "headerAdmin.php";
    ?>
    <br>
    <div class="affiche">
        <div class="row">
            <div class="col-10">
                <div class='card cardbody1 border-warning mb-3'>
                    <div class='card-header'>
                        <h2>Liste des Articles</h2>
                    </div>
                    <div class='card-body'>
                        <div class="row row-cols-1 g-4">
                            <?php
                            $displayAllArticles = new Article();
                            $displayAllArticles->displayAllArticles();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <?php
    require "footer.php";
    ?>
</body>

</html>