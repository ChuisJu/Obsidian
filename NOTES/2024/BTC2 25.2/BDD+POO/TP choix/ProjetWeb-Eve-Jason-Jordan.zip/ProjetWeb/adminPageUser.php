<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

if ($_SESSION["role"] != 0) {
    header("Location: accessDenied.php");
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Modifier Utilisateur</title>
</head>

<body>
    <?php
    require "headerAdmin.php";
    ?>
    <h2>Liste des utilisateurs</h2>

    <?php
    $displayUsers = new Utilisateur();
    $displayUsers->displayUsers();
    ?>

</body>

</html>