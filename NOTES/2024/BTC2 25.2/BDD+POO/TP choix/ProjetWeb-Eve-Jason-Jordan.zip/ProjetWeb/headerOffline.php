<header>
    <img class='logou' src='img/logo.png' alt=''>
    <nav class="allNav">
        <ul class="navlinks">
            <li><a href="login.php" class="link linki">Connexion</a></li>
            <li><a href="register.php" class="link linki">Inscription</a></li>


        </ul>
    </nav>
</header>