<footer>
    <p>Copyright © 2024 BLOG - Tous droits réservés.</p>
</footer>