<?php
session_start();

//Classe qui permet la connexion à la base de données
class Database
{
    public $host = "localhost";
    public $user = "root";
    public $name = "blogg";
    public $bdd;

    public function __construct()
    {
        $this->bdd = new PDO("mysql:host=$this->host;dbname=$this->name", $this->user);
    }
}

//Classe qui permet de gérer la connexion et l'inscription sur le site
class Authentification extends Database
{
    public $idUser;
    public $roleUser;

    public function getIdUser()
    {
        return $this->idUser;
    }

    public function getRoleUser()
    {
        return $this->roleUser;
    }

    //Fonction qui permet de se connecter au site
    public function login($email, $password)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM utilisateur WHERE email_utilisateur = :email");
        $query1->bindParam(":email", $email);
        $query1->execute();
        $row = $query1->fetch(PDO::FETCH_ASSOC);

        if ($row == true) {
            if (password_verify($password, $row["mdp_utilisateur"]) == true) {
                $this->idUser = $row["id_utilisateur"];
                $this->roleUser = $row["role_utilisateur"];

                if ($this->roleUser == 0) {
                    header("Location: admin.php");
                }
                if ($this->roleUser == 1) {
                    header("Location: index.php");
                }
            } else {
                echo "Mot de passe incorrect";
            }
        } else {
            echo "Email incorrect";
        }
    }

    //Fonction qui permet de s'inscrire sur le site
    public function registration($pseudo, $email, $password, $confirmPassword)
    {
        if (!empty($pseudo) && !empty($email) && !empty($password) && !empty($confirmPassword)) {
            $query1 = $this->bdd->prepare("SELECT pseudo_utilisateur, email_utilisateur FROM utilisateur WHERE pseudo_utilisateur = :pseudo OR email_utilisateur = :email");
            $query1->bindParam(":pseudo", $pseudo);
            $query1->bindParam(":email", $email);
            $query1->execute();

            if ($query1->rowCount() > 0) {
                echo "Pseudo ou email déjà utilisé";
            } else {
                if ($password == $confirmPassword) {
                    $role = 1;
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                    $query2 = $this->bdd->prepare("INSERT INTO utilisateur(pseudo_utilisateur, email_utilisateur, mdp_utilisateur, role_utilisateur) VALUES (:pseudo, :email, :mdp, :roles)");
                    $query2->bindParam(":pseudo", $pseudo);
                    $query2->bindParam(":email", $email);
                    $query2->bindParam(":mdp", $passwordHash);
                    $query2->bindParam(":roles", $role);

                    if ($query2->execute()) {
                        echo "Inscription réussie !";
                    }
                }
            }
        } else {
            echo "Veuillez compléter tous les champs !";
        }
    }
}

//Classe qui permet de gérer les utilisateurs
class Utilisateur extends Database
{
    //Fonction qui permet d'afficher la liste de tous les utilisateurs
    public function displayUsers()
    {
        $query1 = $this->bdd->prepare("SELECT * FROM utilisateur;");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            echo "
            <div class='card text-center mb-3 cardbody2' style='width: 18rem;'>
            <div class='card-body'>
             <h5 class='card-title'>Pseudo :{$row['pseudo_utilisateur']} </h5>
            <p class='card-text'>ID : {$row['id_utilisateur']}<br>Email : {$row['email_utilisateur']}</p>
            <a href='editUser.php?idUser={$row['id_utilisateur']}' class='btn btn-warning'>Modifier</a>
            <a href='deleteUser.php?idUser={$row['id_utilisateur']}' class='btn btn-danger'>Supprimer</a>
            </div>
            </div>";
        }
    }

    //Fonction qui permet de supprimer un utilisateur
    public function deleteUser($idUser)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM utilisateur WHERE id_utilisateur = :idUser");
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();

        if ($query1->rowCount() > 0) {
            $query2 = $this->bdd->prepare("DELETE FROM utilisateur WHERE id_utilisateur = :idUser");
            $query2->bindParam(":idUser", $idUser);
            $query2->execute();
        } else {
            echo "Utilisateur inexistant";
        }
    }

    //Fonction qui permet de modifier le pseudo d'un utilisateur
    public function editPseudo($newPseudo, $idUser)
    {
        if (isset($newPseudo)) {
            $query1 = $this->bdd->prepare("UPDATE utilisateur SET pseudo_utilisateur = :newpseudo WHERE id_utilisateur = $idUser");
            $query1->bindParam(":newpseudo", $newPseudo);
            $query1->execute();
            echo "Pseudo modifié";
        } else {
            echo "Veuillez compléter le champs que vous souhaitez modifier !";
        }
    }

    //Fonction qui permet de modifier l'email d'un utilisateur
    public function editEmail($newEmail, $idUser)
    {
        if (isset($newEmail)) {
            $query1 = $this->bdd->prepare("UPDATE utilisateur SET email_utilisateur = :newemail WHERE id_utilisateur = $idUser");
            $query1->bindParam(":newemail", $newEmail);
            $query1->execute();
            echo "Email modifié";
        } else {
            echo "Veuillez compléter le champs que vous souhaitez modifier !";
        }
    }

    //Fonction qui permet de modifier le mot de passe d'un utilisateur
    public function editPassword($newPass, $confirmPass, $idUser)
    {
        if (isset($newPass) && isset($confirmPass)) {
            if ($newPass == $confirmPass) {
                $newPasswordHash = password_hash($newPass, PASSWORD_DEFAULT);
                $query1 = $this->bdd->prepare("UPDATE utilisateur SET mdp_utilisateur = :newpassword WHERE id_utilisateur = $idUser");
                $query1->bindParam(":newpassword", $newPasswordHash);
                $query1->execute();
                echo "Mot de passe modifié";
            } else {
                echo "Les mots de passe ne correspondent pas";
            }
        } else {
            echo "Veuillez compléter le champs que vous souhaitez modifier !";
        }
    }
}

//Classe qui permet de gérer les articles
class Article extends Database
{
    //Fonction qui permet de modifier le propriétaire d'un article en cas de suppression du créateur de l'article
    public function updateArticleOwner($idUser)
    {
        $newId = 1;
        $query1 = $this->bdd->prepare("UPDATE article SET id_utilisateur = :newId WHERE id_utilisateur = :idUser");
        $query1->bindParam(":newId", $newId);
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();
    }

    //Fonction qui permet de supprimer un article
    public function deleteArticle($idArticle)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM article WHERE id_article = :idArticle");
        $query1->bindParam(":idArticle", $idArticle);
        $query1->execute();

        if ($query1->rowCount() > 0) {
            $query2 = $this->bdd->prepare("DELETE FROM article WHERE id_article = :idArticle");
            $query2->bindParam(":idArticle", $idArticle);
            $query2->execute();
        } else {
            echo "Article inexistant";
        }
    }

    //Fonction qui permet d'ajouter un article
    public function addArticle($titre, $contenu, $idUser)
    {
        $query1 = $this->bdd->prepare("INSERT INTO article(titre_article, texte_article, date_article, id_utilisateur) VALUES (:titre, :contenu, NOW(), :idUser)");
        $query1->bindParam(":titre", $titre);
        $query1->bindParam(":contenu", $contenu);
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();
        echo "Article ajouté avec succès";
    }

    //Fonction qui permet d'afficher toutes les informations de tous les articles
    public function displayAllArticles()
    {
        $query1 = $this->bdd->prepare("SELECT id_article, titre_article, date_article, pseudo_utilisateur FROM article a INNER JOIN utilisateur u ON a.id_utilisateur = u.id_utilisateur ORDER BY a.id_article");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idArticle = $row["id_article"];
            echo "<div class='col'>
            <div class='card cardbody2 border-info mb-3'>
            <div class='card-header'>Titre : {$row['titre_article']}</div>
            <div class='card-body'>
            <div class='card-title'>Créateur : {$row['pseudo_utilisateur']}</div>
            <span class='card-text'>Posté le {$row['date_article']}</span><br>
            <a href='viewArticle.php?idArticle=$idArticle' class='voir'>Voir</a><br>
            </div>
            </div>
            </div><br><br>";
        }
    }


    //Fonction qui permet d'afficher les informations d'un seul article
    public function displayArticle($idArticle)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM article a INNER JOIN utilisateur u ON a.id_utilisateur = u.id_utilisateur WHERE id_article = :idArticle");
        $query1->bindParam(":idArticle", $idArticle);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $id = $row["id_article"];
            echo "<div class='row'>
            <div class='col-3'>
                <div class='card mb-3'>
                    <div class='card-body'>
                        <h5 class='card-title'> Sujet publié par :</h5>
                        <p class='card-text'>{$row['pseudo_utilisateur']}.</p>
                        <p class='card-text'>Date de publication : </p>
                        <p class='card-text'> {$row['date_article']}</p>
                    </div>
                </div>
            </div>
            <div class='col-8'>
                <div class='row row-cols-1 g-4'><div class='col'>
            <div class='card cardbody2 border-info mb-3'>
            <div class='card-header'><h2>Sujet : {$row['titre_article']}</h2></div>
            <div class='card-body'>
            <p>{$row['texte_article']}</p>
            </div>
           ";
        }
    }

    //Fonction qui permet d'afficher tous les articles en fonction de l'utilisateur
    public function displayAllArticlesUser($idUser)
    {
        $query1 = $this->bdd->prepare("SELECT id_article, titre_article, date_article, pseudo_utilisateur FROM article a INNER JOIN utilisateur u ON a.id_utilisateur = u.id_utilisateur WHERE a.id_utilisateur = :idUser ORDER BY a.id_article");
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idArticle = $row["id_article"];
            echo "<div class='col'>
            <div class='card cardbody2 border-info mb-3'>
            <div class='card-header'>Titre : {$row['titre_article']}</div>
            <div class='card-body'>
            <div class='card-title'>Créateur : {$row['pseudo_utilisateur']}</div>
            <span class='card-text'>Posté le {$row['date_article']}</span><br>
            <a href='viewArticle.php?idArticle=$idArticle' class='voir'>Voir</a><br>
            <a href='deleteArticle.php?idArticle=$idArticle' class='delete'>Supprimer</a><br>
            </div>
            </div>
            </div><br><br>";
        }
    }

    //Fonction qui permet d'afficher tous les articles pour l'administrateur
    public function displayAllArticlesAdmin()
    {
        $query1 = $this->bdd->prepare("SELECT id_article, titre_article, date_article, pseudo_utilisateur FROM article a INNER JOIN utilisateur u ON a.id_utilisateur = u.id_utilisateur ORDER BY a.id_article");
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idArticle = $row["id_article"];
            echo "<div class='col'>
            <div class='card cardbody2 border-info mb-3'>
            <div class='card-header'>Titre : {$row['titre_article']}</div>
            <div class='card-body'>
            <div class='card-title'>Créateur : {$row['pseudo_utilisateur']}</div>
            <span class='card-text'>Posté le {$row['date_article']}</span><br>
            <a href='viewArticle.php?idArticle=$idArticle' class='voir'>Voir</a><br>
            <a href='deleteArticle.php?idArticle=$idArticle' class='delete'>Supprimer</a><br>
            </div>
            </div>
            </div><br><br>";
        }
    }
}

//Classe qui permet de gérer les commentaires
class Commentaire extends Database
{
    //Fonction qui permet de supprimer le commentaire d'un utilisateur
    public function deleteDeletedUserComment($idUser)
    {
        $query1 = $this->bdd->prepare("DELETE FROM commentaire WHERE id_utilisateur = :idUser");
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();
    }

    //Fonction qui permet de supprimer tous les commentaires d'un article en cas de suppression de cette article
    public function deleteAllArticleComment($idArticle)
    {
        $query1 = $this->bdd->prepare("DELETE FROM commentaire WHERE id_article = :idArticle");
        $query1->bindParam(":idArticle", $idArticle);
        $query1->execute();
    }

    //Fonction qui permet d'afficher tous les articles pour le rôle utilisateur 
    public function displayAllCommentsArticleUser($idArticle)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM commentaire c INNER JOIN article a ON c.id_article = a.id_article WHERE c.id_article = :idArticle");
        $query1->bindParam(":idArticle", $idArticle);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idUser = $row["id_utilisateur"];

            $query2 = $this->bdd->prepare("SELECT pseudo_utilisateur FROM utilisateur WHERE id_utilisateur = :idUser");
            $query2->bindParam(":idUser", $idUser);
            $query2->execute();
            $data = $query2->fetch(PDO::FETCH_ASSOC);
            $pseudo = $data["pseudo_utilisateur"];


            echo "
            <hr class='my-0' style='height: 1px;' /><div class='card-body comentario'>
            <h6 class='fw-bold mb-1'>$pseudo</h6>
            <div class='row '>
            <div class='col-1'><img class='reply' src='img/reply.png' alt=''></div>
            <div class='col'>
            <p>{$row['texte_commentaire']}</p>
            </div>
            </div>
            <div class='date'>Commenté le {$row['date_commentaire']}</div>
            </div>
            ";
        }
    }

    //Fonction qui permet d'afficher tous les articles pour le rôle admin
    public function displayAllCommentsArticleAdmin($idArticle)
    {
        $query1 = $this->bdd->prepare("SELECT * FROM commentaire c INNER JOIN article a ON c.id_article = a.id_article WHERE c.id_article = :idArticle");
        $query1->bindParam(":idArticle", $idArticle);
        $query1->execute();
        $data1 = $query1->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data1 as $row) {
            $idUser = $row["id_utilisateur"];
            $idComment = $row["id_commentaire"];
            $idArticle = $row["id_article"];

            $query2 = $this->bdd->prepare("SELECT pseudo_utilisateur FROM utilisateur WHERE id_utilisateur = :idUser");
            $query2->bindParam(":idUser", $idUser);
            $query2->execute();
            $data = $query2->fetch(PDO::FETCH_ASSOC);
            $pseudo = $data["pseudo_utilisateur"];

            echo "
            <hr class='my-0' style='height: 1px;' /><div class='card-body comentario'>
            <h6 class='fw-bold mb-1'>$pseudo</h6>
            <div class='row '>
            <div class='col-1'><img class='reply' src='img/reply.png' alt=''></div>
            <div class='col'>
            <p>{$row['texte_commentaire']}</p>
            </div>
            </div>
            <div class='date'>Commenté le {$row['date_commentaire']}</div>
            <a href='deleteCommentaire.php?idComment=$idComment&idArticle=$idArticle' class='delete'>Supprimer</a>
            </div>
            ";
        }
    }

    //Fonction qui permet d'ajouter un commentaire
    public function addCommentaire($comment, $idArticle, $idUser)
    {
        $query1 = $this->bdd->prepare("INSERT INTO commentaire(texte_commentaire, date_commentaire, id_article, id_utilisateur) VALUES (:comment, NOW(), :idArticle, :idUser)");
        $query1->bindParam(":comment", $comment);
        $query1->bindParam(":idArticle", $idArticle);
        $query1->bindParam(":idUser", $idUser);
        $query1->execute();

        echo '<script type="text/javascript">';
        echo 'alert("Commentaire ajouté")';
        echo '</script>';
    }

    //Fonction qui permet de supprimer un commentaire
    public function deleteComment($idComment)
    {
        $query1 = $this->bdd->prepare("DELETE FROM commentaire WHERE id_commentaire = :idComment");
        $query1->bindParam(":idComment", $idComment);
        $query1->execute();
    }
}
