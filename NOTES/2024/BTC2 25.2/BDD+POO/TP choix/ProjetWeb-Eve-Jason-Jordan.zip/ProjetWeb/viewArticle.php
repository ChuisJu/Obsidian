<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

if (isset($_POST["submit"])) {
    $addCommentaire = new Commentaire();
    $addCommentaire->addCommentaire($_POST["comment"], $_GET["idArticle"], $_SESSION["id"]);
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Article</title>
</head>

<body>
    <?php
    if ($_SESSION["role"] == 0) {
        require "headerAdmin.php";
    }
    if ($_SESSION["role"] == 1) {
        require "headerUser.php";
    }
    ?>


    <br>
    <div class="affiche">

        <?php
        if (isset($_GET["idArticle"])) {
            $displayArticle = new Article();
            $displayArticle->displayArticle($_GET["idArticle"]);
        }
        ?>
        <br><br>
        <form method="POST">
            <div class="form-floating">
                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="comment"></textarea>
                <label for="floatingTextarea">Entrer votre commentaire</label>
            </div>

            <input type="submit" name="submit" class="sub-box">
        </form>
        <br>
        <?php
        if ($_SESSION["role"] == 0 && isset($_GET["idArticle"])) {
            $displayAllCommentsArticleAdmin = new Commentaire();
            $displayAllCommentsArticleAdmin->displayAllCommentsArticleAdmin($_GET["idArticle"]);
        }
        if ($_SESSION["role"] == 1 && isset($_GET["idArticle"])) {
            $displayAllCommentsArticleUser = new Commentaire();
            $displayAllCommentsArticleUser->displayAllCommentsArticleUser($_GET["idArticle"]);
        }
        ?>

    </div>

    </div><br><br>
    <div class="col"></div>
    </div>

    </div>
    </div>

    </div>







    <?php
    require "footer.php";
    ?>
</body>

</html>