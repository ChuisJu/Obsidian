<?php
require "classes.php";

if (empty($_SESSION["id"])) {
    header("Location: login.php");
}

$addArticle = new Article();

if (isset($_POST["submit"])) {
    $addArticle->addArticle($_POST["titre"], $_POST["contenu"], $_SESSION["id"]);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Ajouter un article</title>
</head>

<body>

    <?php
    if ($_SESSION["role"] == 0) {
        require "headerAdmin.php";
    }
    if ($_SESSION["role"] == 1) {
        require "headerUser.php";
    }
    ?>

    <h3>Ajouter un article</h3>
    <br><br><br><br><br><br>

    <div class="login2-box">
        <h1>Ajouter un titre à votre article</h1>
        <form method="POST">
            <div class="user-box">
                <input type="text" name="titre" placeholder="Titre" required>
                <label for="Titre">Ajouter un titre à votre article</label>
            </div>
            <br><br>
            <div class="user-box">

                <!-- <input type="textarea" name="bio" placeholder="biographie" required> -->
                <textarea name="contenu" cols="60" rows="10" placeholder="Contenu" required></textarea><br>
                <label for="contenu">Ajouter du contenu à votre article</label>
            </div>


            <input class="sub-box" type="submit" name="submit" value="Valider">
        </form>
    </div>
    <br><br><br><br><br><br><br><br>


    <?php
    require "footer.php";
    ?>
</body>

</html>