<?php
require "classes.php";

$idUser = $_GET["idUser"];

$deleteDeletedUserComment = new Commentaire();
$deleteDeletedUserComment->deleteDeletedUserComment($idUser);

$updateArticleOwner = new Article();
$updateArticleOwner->updateArticleOwner($idUser);

$deleteMember = new Utilisateur();
$deleteMember->deleteUser($idUser);

header("Location: admin.php");
