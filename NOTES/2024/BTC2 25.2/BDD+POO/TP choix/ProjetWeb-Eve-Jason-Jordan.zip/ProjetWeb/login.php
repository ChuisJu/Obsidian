<?php
require "classes.php";

if (!empty($_SESSION["id"])) {
    if ($_SESSION["role"] == 0) {
        header("Location: admin.php");
    } elseif ($_SESSION["role"] == 1) {
        header("Location: index.php");
    }
}

if (isset($_POST["submit"])) {
    $login = new Authentification();
    $login->login($_POST["email"], $_POST["password"]);
    $_SESSION["id"] = $login->getIdUser();
    $_SESSION["role"] = $login->getRoleUser();
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require "style.php";
    ?>
    <title>Connexion</title>
</head>

<body>
    <?php
    require "headerOffline.php";
    ?>

    <div class="login-box">
        <h1>Connexion</h1>
        <form method="POST">
            <div class="user-box">
                <input type="mail" name="email" placeholder="Email" required>
                <label for="mail">Email </label>
            </div>
            <div class="user-box">
                <input type="password" name="password" placeholder="Mot de passe" required>
                <label for="password">Mot de passe </label>
            </div>

            <input class="sub-box" type="submit" name="submit" value="Connexion">
        </form>
    </div>

    <?php
    require "footer.php";
    ?>
</body>

</html>