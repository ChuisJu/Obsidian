<?php
require "classes.php";

$idComment = $_GET["idComment"];
$idArticle = $_GET["idArticle"];

$deleteComment = new Commentaire();
$deleteComment->deleteComment($idComment);

header("Location: viewArticle.php?idArticle=$idArticle");
