<?php
require "classes.php";

$idArticle = $_GET["idArticle"];

$deleteArticleComment = new Commentaire();
$deleteArticleComment->deleteAllArticleComment($idArticle);

$deleteArticle = new Article();
$deleteArticle->deleteArticle($idArticle);

if ($_SESSION["role"] == 0) {
    header("Location: adminPageArticle.php");
}

if ($_SESSION["role"] == 1) {
    header("Location: userPageArticle.php");
}
