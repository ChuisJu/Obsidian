DROP DATABASE IF EXISTS blogg;
CREATE DATABASE blogg;
USE blogg;

CREATE TABLE utilisateur(
id_utilisateur INT AUTO_INCREMENT,
pseudo_utilisateur VARCHAR(50),
email_utilisateur VARCHAR(50),
mdp_utilisateur VARCHAR(255),
role_utilisateur INT,
PRIMARY KEY(id_utilisateur)
);

CREATE TABLE article(
id_article INT AUTO_INCREMENT,
titre_article VARCHAR(100),
texte_article TEXT(1000),
date_article DATETIME,
id_utilisateur INT NOT NULL,
PRIMARY KEY(id_article),
FOREIGN KEY(id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
);

CREATE TABLE commentaire(
id_commentaire INT AUTO_INCREMENT,
texte_commentaire VARCHAR(255),
date_commentaire DATETIME,
id_article INT NOT NULL,
id_utilisateur INT NOT NULL,
PRIMARY KEY(id_commentaire),
FOREIGN KEY(id_article) REFERENCES Article(id_article),
FOREIGN KEY(id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
);

INSERT INTO utilisateur(pseudo_utilisateur, email_utilisateur, mdp_utilisateur, role_utilisateur) 
VALUES
("admin", "admin@admin.fr", "$2y$10$UoH2srVXzWYl9qV77pbPeuR4LGNswgKiKZQ1JEXBCm25epYTCqV7y", 0);
-- motdepass admin : admin123
