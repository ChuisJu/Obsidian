<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'getAll.php';

// Création d'une instance de la classe Database pour établir la connexion à la base de données
$db = new Database();
$bdd = $db->getConnection();

// Création d'une instance de la classe GetAll pour obtenir les données depuis la base de données
$getAll = new GetAll($db);

$allArticles = $getAll->getAllArticles();


// Vérifier si l'utilisateur est authentifié
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // Rediriger vers la page de connexion s'il n'est pas authentifié
    header('Location: ../login-register/login_view.html');
    exit;
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des articles</title>

    <style>
        /* Styles CSS pour la mise en page */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: linear-gradient(70deg, SlateBlue, MediumSlateBlue, lightblue);
        }


        body {
            text-align: center;
        }

        h2 {
            margin-top: 20px; /* Ajoute une marge en haut pour l'esthétique */
        }

        table {
            margin: 0 auto; /* Centre la table horizontalement */
        }

        td {
            padding: 10px; /* Ajoute un peu d'espace autour du contenu de chaque cellule */
        }

        .encadre {
            max-width: 800px; /* Définit une largeur maximale pour le div */
            margin: 0 auto; /* Centre le div horizontalement */
            background-color: #F2F3F4; /* Ajoute une couleur de fond au div */
            padding: 20px; /* Ajoute un espace intérieur au div */
            border-radius: 10px; /* Ajoute des coins arrondis au div */
            margin-bottom: 20px; /* Ajoute une marge en bas pour l'esthétique */
        }

        .cont {
            max-width: 700px; /* Définit une largeur maximale pour le div */
            margin: 0 auto; /* Centre le div horizontalement */
            background-color: #E5E7E9; /* Ajoute une couleur de fond au div */
            padding: 20px; /* Ajoute un espace intérieur au div */
            border-radius: 10px; /* Ajoute des coins arrondis au div */
            margin-bottom: 20px; /* Ajoute une marge en bas pour l'esthétique */
        }


        .liens a {
            text-decoration: none;
            color: #2C3231;
            font-weight: bold;
            padding: 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .liens a:hover {
            background-color: #007bff;
            color: #fff;
        }

        h1{
            font-family: 'Courier New';
        }
    </style>
</head>
<body>

    <h1>Bienvenue sur la page d'accueil, <?php echo htmlspecialchars($_SESSION['user']); ?> !</h1>
    <br>
    <br>
    <br>
    <div class="liens" style="font-family: 'Courier New'">
    <a href="articles/add_articles.html">Ajouter un Article</a>
    <a href="supprimer.php">Supprimer un Article</a>
    </div>
    <br>
    <br>
    <br>


    <h2 style="font-family: 'Courier New'">Liste des articles</h2>
    <br>
    <br>
        <?php foreach ($allArticles as $allArticle): ?>
            <tr>
                <div class = "encadre">
                <td><?= htmlspecialchars($allArticle['titre'])?>
                </td>

                <div class = "cont">
                <td><?= htmlspecialchars($allArticle['contenue']) ?></td>
                </div>

                <td><a href="commentaire/add_commentaire.php?id_articles=<?php echo $allArticle['id']; ?>">Commentaire</a></td>
                <br>
                <td><a href="articles/afficher_commentaire.php?id_articles=<?php echo $allArticle['id']; ?>">Voir les commentaires</a></td>
                </div>
                <br>
                <br>
                <br>
            </tr>
        <?php endforeach; ?>
</body>
</html>