<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'database.php';
    $id_articles = intval($_GET['id']);
    var_dump($id_articles);

    // Créer une seule instance de la classe Database
    $database = new Database();

    $database->deleteDataById($id_articles);

    // Rediriger vers une autre page après la suppression
    header("Location: supprimer.php");
    exit();
