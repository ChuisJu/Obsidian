<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require 'getAll.php';

// Création d'une instance de la classe Database pour établir la connexion à la base de données
$db = new Database();

// Création d'une instance de la classe GetAll pour obtenir les données depuis la base de données
$getAll = new GetAll($db);

$allArticles = $getAll->getAllArticles();

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <!-- Ajout du lien vers la bibliothèque Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">


    <style>
        /* Styles CSS pour la mise en page */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: linear-gradient(70deg, SlateBlue, MediumSlateBlue, lightblue);
        }


        body {
            text-align: center;
        }

        h2 {
            margin-top: 20px; /* Ajoute une marge en haut pour l'esthétique */
            font-family: 'Courier New', Courier, monospace;
        }

        table {
            margin: 0 auto; /* Centre la table horizontalement */
        }

        td {
            padding: 10px; /* Ajoute un peu d'espace autour du contenu de chaque cellule */
        }

        .encadre {
            max-width: 800px; /* Définit une largeur maximale pour le div */
            margin: 0 auto; /* Centre le div horizontalement */
            background-color: #F2F3F4; /* Ajoute une couleur de fond au div */
            padding: 20px; /* Ajoute un espace intérieur au div */
            border-radius: 10px; /* Ajoute des coins arrondis au div */
            margin-bottom: 20px; /* Ajoute une marge en bas pour l'esthétique */
        }

        .cont {
            max-width: 700px; /* Définit une largeur maximale pour le div */
            margin: 0 auto; /* Centre le div horizontalement */
            background-color: #E5E7E9; /* Ajoute une couleur de fond au div */
            padding: 20px; /* Ajoute un espace intérieur au div */
            border-radius: 10px; /* Ajoute des coins arrondis au div */
            margin-bottom: 20px; /* Ajoute une marge en bas pour l'esthétique */
        }


        .liens a {
            text-decoration: none;
            color: #2C3231;
            font-weight: bold;
            padding: 10px;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .liens a:hover {
            background-color: #007bff;
            color: #fff;
        }

        h1{
            font-family: 'Courier New';
        }

        .container{
            margin-left: 20px;
            margin-top: 20px;
        }
    </style>


</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-sm-2">
            <a href="login-register/login_view.html" class="btn btn-primary btn-lg btn-block">
                <h4>Connection</h4>
            </a>
        </div>
        <div class="col-sm-2">
            <a href="login-register/register_view.html" class="btn btn-success btn-lg btn-block">
                <h4>Inscription</h4>
            </a>
        </div>
    </div>
</div>

<h2>Blog</h2>

<br>
<br>
<br>
<br>
        <?php foreach ($allArticles as $allArticle): ?>
            <tr>
                <div class = "encadre">
                <td><?= htmlspecialchars($allArticle['titre'])?>
                </td>

                <div class = "cont">
                <td><?= htmlspecialchars($allArticle['contenue']) ?></td>
                </div>
                <td><a href="articles/afficher_commentaire.php?id_articles=<?php echo $allArticle['id']; ?>">Voir les commentaires</a></td>
                </div>
                <br>
                <br>
                <br>
            </tr>
        <?php endforeach; ?>


<!-- Ajout du lien vers la bibliothèque Bootstrap JavaScript (jQuery requis) -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
