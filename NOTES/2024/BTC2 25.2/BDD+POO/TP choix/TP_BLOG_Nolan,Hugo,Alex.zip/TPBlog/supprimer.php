<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'database.php';

$id = $_SESSION['id'];

// Créer une seule instance de la classe Database
$database = new Database();

// Appeler la fonction pour récupérer les articles de l'utilisateur
try {
    $user_Articles = $database->selectDataByID($id);
} catch (Exception $e) {
    // Gérer l'erreur de manière appropriée (afficher un message d'erreur, journalisation, etc.)
    die('Erreur : ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Articles</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

</head>
<body>
    <style>
        body {
            padding: 20px;
            background-color: #D7DDDD;
        }

        .article-container {
            margin-top: 20px;
        }

        .article {
            border: 1px solid black;
            padding: 15px;
            margin-bottom: 15px;
        }

        .delete-btn {
            color: #fff;
            background-color: #dc3545;
            border: 1px solid black;
            padding: 5px 10px;
            text-decoration: none;
        }

        .header-container {
        display: flex;
        align-items: center; /* Aligner les éléments verticalement au centre */
        }

        .header-container a {
            margin-right: 350px; /* Espace entre les deux éléments */
        }
    </style>

        
    <div class="header-container">
        <a href="acceuil.php">Retour à l'accueil</a>
        <h2>Bienvenue sur la page de suppression !</h2>
    </div>

        <br>
        <br>
        <br>
    <div class="container">
        <h3 class="mt-4">Liste de mes articles</h3>

        <div class="article-container">
            <?php foreach ($user_Articles as $user_Article): ?>
                <div class="article">
                    <h3><?= htmlspecialchars($user_Article['titre']) ?></h3>
                    <p><?= htmlspecialchars($user_Article['contenue']) ?></p>
                    <a href="traitement_supp.php?id=<?= $user_Article['id']; ?>" class="delete-btn">Supprimer</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
