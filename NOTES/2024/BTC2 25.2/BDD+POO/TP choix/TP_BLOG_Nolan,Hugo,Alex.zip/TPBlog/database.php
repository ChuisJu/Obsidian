<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Définition de la classe Database
class Database {
    // Propriétés privées pour stocker les informations de connexion à la base de données
    private $host = "localhost"; // Adresse du serveur MySQL
    private $dbName = "blog"; // Nom de la base de données
    private $username = "root"; // Nom d'utilisateur MySQL
    private $password = ""; // Mot de passe MySQL
    private $bdd; // Objet PDO pour la connexion à la base de données

    // Constructeur de la classe
    public function __construct() {
        $this->bdd = null; // Initialisation de l'objet PDO à null

        try {
            // Création d'une connexion PDO à la base de données en utilisant les informations de connexion
            $this->bdd = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbName . ";charset=utf8", $this->username, $this->password);

            // Définition du mode d'erreur PDO sur Exception, ce qui permet de gérer les erreurs avec des exceptions
            $this->bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            // En cas d'erreur lors de la connexion, affichage d'un message d'erreur
            die('Erreur : ' . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->bdd; // Retourne l'objet PDO représentant la connexion à la base de données
    }

    public function selectDataById($id) {
        try {
            $query = $this->bdd->prepare("SELECT * FROM articles WHERE id_user = :id");
            $query->bindParam(':id', $id);
            $query->execute();
            $result = $query->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            // Gérez les erreurs PDO ici
            die('Erreur : ' . $e->getMessage());
        }
    }
    


    
// Méthode pour supprimer des données par ID
public function deleteDataById($id_articles) {
    try {
        $query = $this->bdd->prepare("DELETE FROM articles WHERE id = :id");
        $query->bindParam(':id', $id_articles);
        $query->execute();
    } catch (PDOException $e) {
        // Gérez les erreurs PDO en lançant une exception
        throw new Exception('Erreur : ' . $e->getMessage());
    }
}
}
?>