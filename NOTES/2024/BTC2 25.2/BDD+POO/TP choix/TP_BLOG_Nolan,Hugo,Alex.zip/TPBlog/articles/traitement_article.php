<?php
// Inclusion du fichier 'livres.php'
require_once 'articles.php';
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'LivresForm' en utilisant la connexion à la base de données
$form = new ArticleForm($bdd);

// Récupération des informations envoyées via la méthode POST du formulaire
$titre = $_POST['titre'];
$contenue = $_POST['contenue'];

// Appel de la fonction 'insertLivre' pour insérer ces informations dans la base de données
$form->insertLivre($titre, $contenue);
?>