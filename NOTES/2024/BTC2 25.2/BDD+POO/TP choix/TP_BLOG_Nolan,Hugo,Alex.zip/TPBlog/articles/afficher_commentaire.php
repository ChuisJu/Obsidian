<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'Articles.php';

// Création d'une instance de la classe Database pour établir la connexion à la base de données
$db = new Database();
$bdd = $db->getConnection();

$articles = new ArticleForm($bdd);

$id = intval($_GET['id_articles']);

$commentaires = $articles->getCommentaire($id);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des commentaires</title>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            padding: 20px;
            background-color: #D7DDDD;
        }

        h2 {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .no-comment {
            font-style: italic;
            color: #999;
        }

        .header-container {
            margin-left: 20px;
            margin-top: 20px;

        }
    </style>
</head>


<body>

    <div class="header-container">
        <a href="../acceuil.php">Retour à l'accueil</a>
    </div>

    <br>
    <br>
    <br>
    <div class="container">
        <h3>Liste des commentaires</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Contenu</th>
                </tr>
            </thead>
            <tbody>
                <?php if (is_array($commentaires) && !empty($commentaires)): ?>
                    <?php foreach ($commentaires as $commentaire): ?>
                        <tr>
                            <td><?= htmlspecialchars($commentaire['titre']) ?></td>
                            <td><?= htmlspecialchars($commentaire['contenue']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="2" class="no-comment">Aucun commentaire trouvé.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and Popper.js CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
