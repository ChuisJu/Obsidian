<?php
session_start();
require '../database.php';
// Définition de la classe LivresForm
class ArticleForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour insérer un livre dans la base de données
    public function insertLivre($titre, $contenue) {
        try {
            $requete = $this->db->prepare("INSERT INTO articles (titre, contenue, date, id_user) VALUES (?, ?, ?, ?)");
            $date = date("Y-m-d");
            $id_user = $_SESSION['id'];
            $requete->execute([$titre, $contenue, $date, $id_user]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../acceuil.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion du livre : " . $e->getMessage());
        }
    }

    public function getCommentaire($id) {
        $stmt = $this->db->prepare("SELECT * FROM commentaires WHERE id_articles = :id");
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>