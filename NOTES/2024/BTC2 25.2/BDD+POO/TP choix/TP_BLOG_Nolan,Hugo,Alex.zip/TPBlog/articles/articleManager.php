<?php

require_once 'articles.php';  

class ArticleManager
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    // Méthode pour récupérer un article par son ID
    public function getArticleById($id)
    {
        try {
            $query = $this->db->prepare("SELECT * FROM articles WHERE id = ?");
            $query->execute([$id]);

            $articleData = $query->fetch(PDO::FETCH_ASSOC);

            if ($articleData) {
   
                $article = new Article($articleData['id'], $articleData['titre'], $articleData['contenue'], $articleData['date'], $articleData['id_user']);
                return $article;
            } else {
                return null;  // Ajustez selon votre gestion d'erreurs
            }
        } catch (PDOException $e) {
            die("Erreur lors de la récupération de l'article : " . $e->getMessage());
        }
    }
    
    
}
?>