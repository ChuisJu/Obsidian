<?php

session_start();
require_once '../database.php';

class ArticleForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour insérer un article dans la base de données
    public function insertLivre($titre, $contenue) {
        try {
            $requete = $this->db->prepare("INSERT INTO articles (titre, contenue, date, id_user) VALUES (?, ?, ?, ?)");
            $date = date("Y-m-d");
            $id_user = $_SESSION['id'];
            $requete->execute([$titre, $contenue, $date, $id_user]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../acceuil.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion de l'article : " . $e->getMessage());
        }
    }
}
?>