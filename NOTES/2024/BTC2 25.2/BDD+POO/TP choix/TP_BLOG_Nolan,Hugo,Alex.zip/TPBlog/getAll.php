<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Inclusion du fichier 'Database.php' pour accéder à la classe Database
require 'Database.php';

if (isset($_GET['supprimer']) && isset($_GET['id'])) {
    $supprimer = $_GET['supprimer'];
    $id = $_GET['id'];


    // Vérifie si l'ID de l'article à supprimer est fourni
    if ($supprimer == 'true') {
        // Crée une instance de la classe Database
        $db = new Database();

        // Crée une instance de la classe GetAll en passant la connexion à la base de données
        $getAll = new GetAll($db);

        // Appelle la méthode deleteArticle pour supprimer l'article
        $getAll->deleteArticle($id); 
        echo 'good';
    }
}
// Définition de la classe GetAll
class GetAll {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Méthode pour obtenir tous les livres depuis la base de données
    public function getAllArticles() {
        $pdo = $this->db->getConnection(); // Récupération de l'objet PDO pour la connexion

        // Préparation de la requête SQL pour sélectionner tous les livres
        $stmt = $pdo->prepare("SELECT id, titre, contenue FROM articles");
        $stmt->execute(); // Exécution de la requête
        return $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupération des résultats sous forme de tableau associatif
    }

    // Méthode pour supprimer un article en fonction de son ID
    public function deleteArticle($id) {
        $pdo = $this->db->getConnection(); // Récupération de l'objet PDO pour la connexion

        // Préparation de la requête SQL pour supprimer l'article en fonction de son ID
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = :id");
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute(); // Exécution de la requête
    }
}
?>
