<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../database.php';

function verifUser($user_pseudo){
    $database = new Database();
    $bdd = $database->getConnection();
    $verifUser = $bdd->prepare('SELECT pseudo FROM users WHERE pseudo = ?');
    $verifUser->execute(array($user_pseudo));
    return $verifUser;
}

function registerUser($user_pseudo, $user_email, $user_password){
    $database = new Database();
    $bdd = $database->getConnection();
    $insertUserOnWebsite = $bdd->prepare('INSERT INTO users(pseudo, email, password) VALUES(?, ?, ?)');
    $insertUserOnWebsite->execute(array($user_pseudo, $user_email, $user_password));
}


if(isset($_POST['validate'])){
    $user_pseudo = htmlspecialchars($_POST['pseudo']);
    $user_email = htmlspecialchars($_POST['email']);
    $user_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $verifUser = verifUser($user_pseudo);

    if($verifUser->rowCount() == 0){
        registerUser($user_pseudo, $user_email, $user_password);
        header('Location: ../login-register/login_view.html');
        exit;
    } else {
        $erreur = "Pseudo déjà existant";
        header('Location: ../login-register/register_view.php?type=user&erreur=' . $erreur);
    }
}
elseif(!isset($_POST)){
    $erreur = "Error 401";
    echo '<script>window.alert("' . $erreur . '");</script>';
}