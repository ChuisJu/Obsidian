<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once '../database.php';

function verifUser($user_pseudo, $user_password){
    $database = new Database();
    $bdd = $database->getConnection();
    $checkIfUserExists = $bdd->prepare('SELECT id, pseudo, password FROM users WHERE pseudo = ?');
    $checkIfUserExists->execute(array($user_pseudo));

    if($checkIfUserExists->rowCount() > 0){
        $usersInfos = $checkIfUserExists->fetch();

        if(password_verify($user_password, $usersInfos['password'])){
            $_SESSION['auth'] = true;
            $_SESSION['id'] = $usersInfos['id'];
            $_SESSION['user'] = $usersInfos['pseudo'];
            return true; // Utilisateur authentifié
        } else {
            return false; // Mot de passe incorrect
        }
    } else {
        return false; // Utilisateur non trouvé
    }
}

if(isset($_POST['validate'])) {
    $user_pseudo = $_POST['pseudo'];
    $user_password = $_POST['password'];

    if (verifUser($user_pseudo, $user_password)) {
        header('Location: ../acceuil.php');
        exit;
    } else {
        $erreur = "Identifiant ou mot de passe incorrect";
        echo 'Identifiant ou mot de passe incorrect';
    }
}

if(isset($_GET['erreur'])){
    $erreur = "Identifiant ou mot de passe incorrect";
    echo '<script>window.alert("' . $erreur . '");</script>';
}
include_once('../login-register/login_view.html');
?>