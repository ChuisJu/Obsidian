<?php 
$id_article = intval($_GET['id_articles']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter article</title>
</head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            padding: 20px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            font-weight: bold;
        }

        textarea {
            resize: vertical;
        }

        button {
            color: #fff;
            background-color: #007bff;
            border: 1px solid #007bff;
            padding: 8px 16px;
            cursor: pointer;
        }

        .header-container {
            margin-left: 20px;
            margin-top: 20px;

        }

        body{
            background-color: #D7DDDD;
        }
    </style>
</head>
<body>

    <div class="header-container">
        <a href="../acceuil.php">Retour à l'accueil</a>
    </div>

    <!-- Formulaire de traitement de commentaire -->
    <form action="traitement_commentaire.php" method="post">
        <div class="form-group">
            <label for="titre">Titre :</label>
            <input type="text" class="form-control" name="titre" required>
        </div>

        <div class="form-group">
            <label for="contenu">Contenu :</label>
            <textarea class="form-control" name="contenu" rows="4"></textarea>
        </div>

        <!-- Ajoutez l'attribut 'name' à l'input pour l'ID de l'article -->
        <input type="hidden" name="id_articles" value="<?php echo $id_article; ?>">

        <button type="submit" class="btn btn-primary" name="validate">Ajouter un commentaire</button>
    </form>

    <!-- Bootstrap JS and Popper.js CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

