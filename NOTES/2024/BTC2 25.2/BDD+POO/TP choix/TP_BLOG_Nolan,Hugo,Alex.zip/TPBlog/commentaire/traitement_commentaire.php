<?php
// Inclusion du fichier 'livres.php'
require 'commentaire.php';


// Création d'une instance de la classe 'Database' pour gérer la connexion à la base de données
$db = new Database();

// Établissement de la connexion à la base de données
$bdd = $db->getConnection();

// Création d'une instance de la classe 'LivresForm' en utilisant la connexion à la base de données
$form = new CommentaireForm($bdd);

if(isset($_POST['validate'])){
// Récupération des informations envoyées via la méthode POST du formulaire
$titre = $_POST['titre'];
$contenue = $_POST['contenu'];
$id_articles = $_POST['id_articles'];

// Appel de la fonction 'insertLivre' pour insérer ces informations dans la base de données
$form->insertCommentaire($titre, $contenue, $id_articles);
}
?>