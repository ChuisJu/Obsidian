<?php
// Inclusion du fichier 'Database.php'
session_start();
require_once '../database.php';

// Définition de la classe LivresForm
class CommentaireForm {
    // Propriété privée pour stocker la connexion à la base de données
    private $db;

    // Constructeur de la classe
    public function __construct($db) {
        $this->db = $db;
    }

    // Fonction pour insérer un livre dans la base de données
    public function insertCommentaire($titre, $contenue, $id_articles) {
        try {
            $requete = $this->db->prepare("INSERT INTO commentaires (titre, contenue, id_articles, id_user) VALUES (?, ?, ?, ?)");
            $id_user = $_SESSION['id'];
            $requete->execute([$titre, $contenue, $id_articles, $id_user]);

            // Redirection vers une autre page après l'insertion
            header('Location: ../acceuil.php');
            exit();
        } catch (PDOException $e) {
            // En cas d'erreur, afficher un message d'erreur
            die("Erreur lors de l'insertion du livre : " . $e->getMessage());
        }
    }
}
?>