<?php
require('heros.php');
require('attack.php');




$choixperso;
 
$Freezer = new Mechant ("Freezer",150,1900,1900,700,11);


$choix = readline("1: Songoku, 2: Vegeta, 3: Piccolo, 4: Songohan");
switch($choix){
    case 1: 
    $choixperso = $Songoku;
    break; 
   
    case 2: 
    $choixperso = $Vegeta;
    break; 
    
    case 3: 
    $choixperso = $Piccolo;
    break;
    
    case 4: 
    $choixperso = $Songohan;
    break;
    
    default:
    echo "choisissez un personnage";
    break;
}


function choixHero($heros, $Freezer){
    echo "\nChoissisez votre personnage : \n\n";
    foreach ($heros as $hero) {
        echo $hero->getHeros();
    }
    $choix = readline("\nEntrez votre choix : ");
    system('clear');

    if ($choix == 1) {
        echo $hero1 = $heros[0]->getHeros();
        choixMechant($GLOBALS['mechants'], $Freezer, $heros);
    }
    elseif ($choix == 2) {
        echo $hero1 = $heros[1]->getHeros();
        choixMechant($GLOBALS['mechants']);
    } 
    elseif ($choix == 3) {
        echo $hero1 = $heros[2]->getHeros();
        choixMechant($GLOBALS['mechants']);
    } 
    elseif ($choix == 4) {
        echo $hero1 = $heros[3]->getHeros();
        choixMechant($GLOBALS['mechants']);
    }  else {
        echo "Choix invalide. Veuillez réessayer.\n";
    }
}

choixhero($heros, $Freezer);

function choixMechant($mechants, $Freezer, $heros){
    foreach ($mechants as $mechant) {
        $mechant->getMechant();
    }

    $tour = 1;
    if ($tour = 1) {
        echo "\nUn combat est lancé contre ".$mechants[$tour - 1]->getMechant()."\n";
        echo "Veuillez choisir votre attaque : \n\n";
        choixAttaque($GLOBALS['attaque'], $Freezer, $heros);
    }
}

while($freezer->getPV()<1 || $heros[0]->getPV()<1){
    choixAttaque($GLOBALS['attaque'], $Freezer, $heros);
}


function choixAttaque($attaque, $Freezer, $heros){

    foreach ($attaque as $attack) {
        echo $attack->getAttack();
    }
    $choixAttaque = readline("\nEntrez votre choix : ");
    $capacité ;
    if ($choixAttaque == 1) {
      $capacité = $attaque[0]->getAttack();
        $Freezer->setPV($Freezer->getPV() - $heros[0]->getAttaque());
        echo $Freezer->getPV()."vous avez attaqué ";
    } 
    elseif ($choixAttaque == 2) {
      
        echo "vous avez esquivé";
    } 
    elseif ($choixAttaque == 3) {
        affichage($GLOBALS['personnage']);
    } 
    elseif ($choixAttaque == 4) {
      
        $heros->setPV($heros->getPV() - 50);
        echo $heros->getPV()."vous avez bloqué ";
    } 
    else {
        echo "Choix invalide. Veuillez réessayer.\n";
    }

 
}




function affichage($personnage){
    foreach ($personnage as $personnages) {
        echo $personnages->getPersonnage();
    }
}
?>