<?php 

require_once ('heros.php');

class Attaque {
    public $nom;
    public $id;

    public function __construct($nom, $id){
        $this->nom = $nom;
        $this->id = $id;

    }

    public function getAttack(){
        $text = "$this->id - $this->nom\n";
        return $text;
    }

    function attack(){

    }
}

$attack = new Attaque("Attaque", 1);
$esquive = new Attaque("Esquive", 2);
$boule = new Attaque("Boule d'énergie", 3);
$parer = new Attaque("Parer", 4);

$attaque = [$attack, $esquive, $boule, $parer];

?>