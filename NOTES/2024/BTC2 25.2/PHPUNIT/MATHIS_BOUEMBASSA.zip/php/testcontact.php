<?php

use PHPUnit\Framework\TestCase;

require_once 'contact.php';

class testontact extends TestCase
{
    public function testenvoimail()
    {
       // test de champs vides 
        $to = '';
        $subject = '';
        $message = '';
        $headers ='';

        $result = mail($to, $subject, $message, $headers);

        $this->assertFalse($result, 'fail');
    }


    public function testenvoimail2()
    {
       // test de mauvaise syntaxe
        $to = 'NoMailSyntaxTest';
        $subject = '';
        $message = '';
        $headers ='';

        $result = mail($to, $subject, $message, $headers);

        $this->assertFalse($result, 'fail');
    }

}

?>