<?php
function envoimail() {

    $from = 'zaki.fake@fakedomain.fr';

    do {
        echo "Entrez l'adresse du destinataire ([ * ] pour quitter) : ";
        $to = trim(fgets(STDIN));

        if (strtolower($to) === '*') {
            echo "Arrêt de l'envoi d'e-mails.\n";
            return; 
        }
    
        preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $to, $match);
    } while (empty($match));

    while (empty($subject)){
    echo "Entrez le sujet du mail : ";
    $subject = trim(fgets(STDIN));
    }

    while (empty($message)){
    echo "Entrez le contenu du mail : ";
    $message = trim(fgets(STDIN));
    }
    
    echo "Entrez les en-têtes du mail : ";
    $headers = "From: $from\r\n";

    while ($line = trim(fgets(STDIN))) {
        if (strtolower($line) === '*') {
            echo "Arrêt de l'envoi d'e-mails.\n";
            return; 
        }
        $headers .= $line . "\r\n";
    }

    if (mail($to, $subject, $message, $headers)) {
        echo "Mail envoyé avec succès !\n";
    } else {
        echo "Erreur lors de l'envoi du mail.\n";
    }
}

envoimail();
?>

