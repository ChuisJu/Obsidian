<?php
function traiterFormulaire($nom, $prenom, $email, $message) {
    // Mettre en place les données du formulaire
    $donnees_formulaire = "Nom: $nom\nPrénom: $prenom\nEmail: $email\nMessage: $message\n\n";

    //Le fichier ou les informations seront enregistrés
    $fichier_texte = "journalisation.txt";

    //Permet d'ouvrir, écrire et fermer le fichier
    $fichier = fopen($fichier_texte, "a");
    fwrite($fichier, $donnees_formulaire);
    fclose($fichier);

    //message pour annoncer que le fichier est bien enregistrée
    echo "Les informations ont été enregistrées dans $fichier_texte";
    exit;
}



if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Vérifie si le npm est en majuscule et si il contient des chiffres
    if (strtoupper($nom) === $nom && !preg_match('/\d/', $nom)) {

        // Vérifie si le prénom contient au moins une majuscule et si il contient des chiffres
        if (!preg_match('/[\d\W]/', $prenom)) {

            //Vérifie si dans email il contient outlook.com ou gmail.com
            if (strpos($email, '@outlook.com') !== false || strpos($email, '@gmail.com') !== false) {
                
                //traiter le formulaire
                traiterFormulaire($nom, $prenom, $email, $message);

            } else {
                echo "L'adresse email contenir outlook.com ou gmail.com";
            }

        } else {
            echo "Le prénom ne doit pas contenir de caractère spéciaux ou de chiffres";
        }

    } else {
        echo "Le nom doit être écrit en majuscules et ne doit pas contenir de chiffres";
    }


} else {
    echo "Vous n'avez pas remplis tout les champs du formulaire.";
}
?>
