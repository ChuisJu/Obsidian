<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire</title>
    <link rel="stylesheet" href="contact.css">
</head>
<body>

    <h2>Formulaire d'envois de mail</h2>

    <form action="traitement_formulaire.php" method="post">
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required><br>

        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required><br>

        <label for="email">Envoyez le mail à :</label>
        <input type="email" id="email" name="email" required><br>

        <label for="message">Message :</label>
        <input type="message" id="message" name="message" required><br>

        <br>

        <input type="submit" name="submit" value="Soumettre">
    </form>

</body>
</html>
