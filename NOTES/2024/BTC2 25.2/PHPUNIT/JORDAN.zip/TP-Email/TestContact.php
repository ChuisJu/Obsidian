<?php
require_once "contact.php";

use PHPUnit\Framework\TestCase;

class TestContact extends TestCase
{
    //Test de updateLogs() avec des données valides
    public function testUpdateLogs()
    {
        $name = "Toto";
        $sender = "toto@toto.fr";
        $receiver = "tata@tata.fr";
        $subject = "Test updateLogs()";
        $message = "Test réussi";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertTrue($test);
    }

    //Test de updateLogs() avec des données vides
    public function testUpdateLogsEmpty()
    {
        $name = "";
        $sender = "";
        $receiver = "";
        $subject = "";
        $message = "";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertFalse($test);
    }

    //Test de updateLogs() sans une des données obligatoires (le nom, l'email de l'expéditeur ou l'email du destinataire)
    public function testWithoutRequiredField()
    {
        $name = "";
        $sender = "";
        $receiver = "";
        $subject = "Test";
        $message = "Test sans les champs requis";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertFalse($test);
    }

    //Test de updateLogs() avec les données obligatoires sans une des données optionnelles (le sujet ou le message) 
    public function testWithoutOptionalField()
    {
        $name = "Toto";
        $sender = "toto@toto.fr";
        $receiver = "tata@tata.fr";
        $subject = "";
        $message = "";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertTrue($test);
    }

    //Test d'un nom avec des caractères spéciaux (exceptés ', -) ou des nombres
    public function testBadNameFormat()
    {
        $name = "*+/54";
        $sender = "toto@toto.fr";
        $receiver = "tata@tata.fr";
        $subject = "Test nom";
        $message = "Test mauvais format du nom";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertFalse($test);
    }

    //Test d'un email avec un mauvais format (email expéditeur ou email destinataire)
    public function testBadEmailFormat()
    {
        $name = "Toto";
        $sender = "azertyuiop";
        $receiver = "tata@tata.fr";
        $subject = "Test email";
        $message = "Test mauvais format de l'email";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertFalse($test);
    }

    //Test d'un message qui a plus de 255 caractères
    public function testMessageTooLong()
    {
        $name = "Toto";
        $sender = "toto@toto.fr";
        $receiver = "tata@tata.fr";
        $subject = "Test message";
        $message = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

        $test = updateLogs($name, $sender, $receiver, $subject, $message);

        $this->assertFalse($test);
    }

    //Test qui vérifie si les données sont bien écrites dans le fichier logs.txt
    public function testFileWriting()
    {
        $name = "Toto";
        $sender = "toto@toto.fr";
        $receiver = "tata@tata.fr";
        $subject = "Test FileWriting";
        $message = "Test sur l'écriture dans le fichier logs.txt";

        updateLogs($name, $sender, $receiver, $subject, $message);

        $file = file_get_contents("logs.txt");

        $expectedContent = "$name \nExpéditeur: $sender \nDestinataire: $receiver \nSujet: $subject \nMessage: $message";

        $this->assertStringContainsString($expectedContent, $file);
    }
}
