<?php
if (isset($_POST["name"]) && isset($_POST["sender"]) && isset($_POST["receiver"])) {
    $name = $_POST["name"];
    $sender = $_POST["sender"];
    $receiver = $_POST["receiver"];
}

if (isset($_POST["subject"])) {
    $subject = $_POST["subject"];
}

if (isset($_POST["message"])) {
    $message = $_POST["message"];
}

//Fonction qui permet de créer le fichier logs.txt et d'y ajouter les logs d'envoi de mails
function updateLogs($name, $sender, $receiver, $subject, $message)
{
    $patternMail = '/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
    $patternName = '/[\/~`\!@#$%\^&\*\(\)_\+=\{\}\[\]\|;:"\<\>,\.\?\\\0-9]/';
    if (!empty($name) && !empty($sender) && !empty($receiver)) {
        if (!preg_match($patternName, $name)) {
            if (preg_match($patternMail, $sender) && preg_match($patternMail, $receiver)) {
                if (strlen($message) <= 255) {
                    $date = date("d/m/y H:i:s");
                    $file = "logs.txt";
                    if (!file_exists($file)) {
                        file_put_contents($file, "");
                    }
                    $content = file_get_contents($file);
                    $content .= "$date \nNom: $name \nExpéditeur: $sender \nDestinataire: $receiver \nSujet: $subject \nMessage: $message\n-----------------------------------------------------------------------------------------------------------------------\n";
                    file_put_contents($file, $content);
                    return true;
                } else {
                    echo "Message trop long (255 caractères maximum)";
                    return false;
                }
            } else {
                echo "Mauvais format d'email";
                return false;
            }
        } else {
            echo "Mauvais format de nom";
            return false;
        }
    } else {
        echo "Remplir les champs obligatoires";
        return false;
    }
}

if (isset($_POST["submit"])) {
    if (updateLogs($name, $sender, $receiver, $subject, $message)) {
        echo "<br>Envoyé";
    } else {
        echo "<br>Echec de l'envoi";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>

<body>
    <h2>Envoyer un mail</h2>
    <form method="POST">
        <label for="name">Nom : </label>
        <input type="text" name="name" placeholder="Nom obligatoire">
        <br><br>
        <label for="sender">De : </label>
        <input type="email" name="sender" placeholder="Email expéditeur obligatoire">
        <br><br>
        <label for="email">À : </label>
        <input type="email" name="receiver" placeholder="Email destinataire obligatoire">
        <br><br>
        <label for="subject">Sujet : </label>
        <input type="text" name="subject" placeholder="Sujet optionnel">
        <br><br>
        <label for="message">Message : </label>
        <br>
        <textarea name="message" cols="30" rows="10" placeholder="Message optionnel"></textarea>
        <br>
        <input type="submit" name="submit">
    </form>
</body>

</html>