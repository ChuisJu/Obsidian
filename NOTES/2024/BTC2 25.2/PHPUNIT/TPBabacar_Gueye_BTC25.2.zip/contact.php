<?php
// Fonctions de validation des champs du formulaire

function validerNom($nom) {
    return preg_match('/^[a-zA-Z]/', $nom);
}

function validerSujet($sujet) {
    return preg_match('/^[a-zA-Z\s]/', $sujet);
}

function validerMessage($msg) {
    return !empty($msg);
}

function validerEmail($mail) {
    return filter_var($mail, FILTER_VALIDATE_EMAIL) !== false;
}

// Fonction de validation globale du formulaire

function validerFormulaire($nom, $mail, $sujet, $message) {
    $erreurs = array();

    if (!validerEmail($mail)) {
        $erreurs[] = "Votre e-mail n'est pas valide";
    }

    if (!validerNom($nom)) {
        $erreurs[] = "Le nom n'est pas valide";
    }

    if (!validerSujet($sujet)) {
        $erreurs[] = "Le sujet n'est pas valide";
    }

    if (!validerMessage($message)) {
        $erreurs[] = "Le message est vide";
    }

    return $erreurs;
}

// Traitement du formulaire

if (isset($_POST["submit"])) {
    $nom = $_POST["nom"];
    $mail = $_POST["mail"];
    $sujet = $_POST["sujet"];
    $msg = $_POST["message"];
    $msg = wordwrap($msg, 50);

    // Validation globale du formulaire
    $validationResult = validerFormulaire($nom, $mail, $sujet, $msg);

    if (empty($validationResult)) {
        // Le formulaire est valide, procéder au traitement
        $logFile = 'journalisation.txt';
        $logMessage = "Date: " . date('Y-m-d H:i:s') . "\n";
        $logMessage .= "Nom: $nom\n";
        $logMessage .= "Destinataire: $mail\n";
        $logMessage .= "Sujet: $sujet\n";
        $logMessage .= "Message:\n$msg\n";

        // Ajout du message au fichier de journalisation
        file_put_contents($logFile, $logMessage, FILE_APPEND);
        echo "Mail envoyé avec succès";
    } else {
        // Afficher les erreurs de validation
        foreach ($validationResult as $erreur) {
            echo $erreur . "<br>";
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TP Mail</title>
    <link rel="stylesheet" href="contact.css"></link>
</head>
<body>
    <div class="card">
    <h1>Formulaire d'envoi</h1>
    <form method="post">
    <label for="Nom">Nom :</label>
    <input type="text" name="nom" ></input><br><br>
    <label for="Email">Email :</label>
    <input type="email" name="mail" ></input><br><br>
    <label for="sujet">Sujet :</label>
    <input type="text" name="sujet"  ></input><br><br>
    <label for="sujet">Message :</label>
    <textarea name="message"  ></textarea><br>   
    <input type="submit" name="submit" value="Envoyer"/>
    </form>
    </div>
</body>
</html>
