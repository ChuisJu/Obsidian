<?php





require_once 'tests.php';

 include 'header.php';?>

<div>

<form action="" method="POST">

 <label for="name">Nom</label>
 <input type="name" value="Entrer votre nom"><br>

<label for="email">Adresse mail</label>
 <input type="email" name="email" value="Entrer votre mail" placeholder="Email" require><br>

 <label for="text">Sujet de l'envoi</label>
 <input type="text" name="texte" value="Entrer votre nom"><br>

 <textarea name="text" id="" cols="30" rows="10">Votre message</textarea>


 <input type="submit" name="submit" value="Envoyer">





</form>



</div>




<?php


include 'footer.php';?>


















?>