<?php

$to = "esthoumba@gmail.com";
$subject=$_POST["text"];
$message= $_POST["text"];
$from=$_POST["email"];
$name=$_POST["name"];


if(isset($_POST["submit"])){
	
	
	//Vérification pour l'envoi d'un message vide

    if(empty($message)){

		mail($to,$subject,$message,$name,$from);
	   
		 echo"Vous n'avez pas écrit de message\n";
	   }
	   else{
		   echo "Message envoyé\n";
	   }

	//Vérifier si le nom n'est pas constitué de nombres

	if(!is_numeric($name)){
		mail($to,$subject,$message,$name,$from);
	echo"Ecrivez sans les chiffres\n";
	}
	else{
		echo "Message envoyé\n";
	}

	//Vérification des lettres majuscules dans le nom
if( !strtolower($name)){
	mail($to,$subject,$message,$name,$from);
echo "Ecrivez en majuscule";

}
else{
	echo "Message envoyé";
}
	

echo "L\'expéditeur'.$name.'a envoyé le message ";

}
















































