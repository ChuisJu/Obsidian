<?php
require "../vendor/autoload.php";
use PHPMailer\PHPMailer\PHPMailer;


class Email {
    //Méthode PHPMailer pour envoyer notre mail
    public function sendEmail($email, $sujet, $message) {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->SMTPAuth = true;

        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->Username = 'contacthighlight63@gmail.com';
        $mail->Password = 'rznm ozrs cdub ufgx ';

        $mail->setFrom($email, 'contact.highlight');
        $mail->addAddress($email);

        $mail->Subject = $sujet;
        $mail->Body = $message;

        return $mail->send();
    }
}
?>
