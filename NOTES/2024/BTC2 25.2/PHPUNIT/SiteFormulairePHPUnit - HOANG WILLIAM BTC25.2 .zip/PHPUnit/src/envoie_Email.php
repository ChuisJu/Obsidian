<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoie Email</title>
    <link rel="stylesheet" href="../assets/envoie_Email.css">
</head>
<body>
    <div class="container">
<?php
require_once 'Email.php';
function formatEmail($email, $sujet, $message)
        {
            // Gestion des erreurs - TEST UNITAIRE

            //Fonction de vérification de l'adresse mail
            function verifyEmail($email) {
            //Format IPV6 Basique
            $formatIPv6 = '/^[^@\s]+@[^@\s]+\.[^@\s.]+$/';



            //Format Email: 1ere partie de l'email (avant le @) supporte les chiffres, lettres (maj et min) et les symboles suivants : '_''+''%''+''-'
            // La 2ème partie de l'email (après le @) supporte les chiffres, lettres (maj et min) et le symbole : '-'
            // La 3ème partie de l'email (après le .) supporte seulement les lettres (maj et min) et prend minimum 2 lettres.
            $formatEmail= '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';



            // Vérifier si l'adresse e-mail ne correspond pas au format IPv6
            if (!preg_match($formatIPv6, $email)) {
                return true;
            // Vérifier si l'adresse e-mail correspond au format email qu'on a créé
            } else if (!preg_match($formatEmail, $email)){
                return true;
            }
            }

            //Fonction pour vérifier si le corps d'un email est vide 
            function emptyEmail($corps_email)
            {
                //supprime les espaces au début et a la fin de la string
                $corps_email_trimmed = trim($corps_email);
                //Vérifie si le corps est vide ou non;
                if (!empty($corps_email_trimmed)) {
                    return false;
                } else return true;
            }


            if (emptyEmail($sujet)) {
                echo "<div class='text'>Le sujet de votre email est vide</div>";
                return;
            }

            if (emptyEmail($message)) {
                echo "<div class='text'>Le contenu de votre email est vide</div>";
                return;
            }

            if(verifyEmail($email)){
                echo "<div class='text'>L'adresse e-mail n'est pas valide</div>";
                return;
            }

            $emailSender = new Email();
            $mailSent = $emailSender->sendEmail($email, $sujet, $message);


            //Vérifie si le mail a bien été envoyé ou non
            if ($mailSent) {
                echo "<div class='text'>Le mail a bien été envoyé</div>";
            } else {
                echo "<div class='text'>Le mail n'a pu être envoyé</div>";
            }

        }
//afficher notre message d'erreur seulement si des données sont retrouvées en méthode post
if (isset($_POST['submit'])) {
?>
    <div>
        <?php
        //Attribution des composants de notre mail avec nos variables
        $email = $_POST['email'];
        $sujet = $_POST['sujet'];
        $message = $_POST['message'];

        formatEmail($email, $sujet, $message);
        ?>
    </div>

<?php }  ?>
</div>
</body>
<!-- Script pour repartir sur la page contact.php -->
<script>setTimeout(()=>window.location.href = "contact.php", 5000)</script>
</html>
