<!-- form.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire mail</title>
    <link rel="stylesheet" href="../assets/index.css">
</head>
<body>
    
    <div class="container">
        <div class="text">
            Formulaire Mail
        </div>
        <form method="POST" action="envoie_Email.php">
            <div class="form-row">
                <div class="input-data">
                    <input type="text" name="email" required>
                    <div class="underline"></div>
                    <label for="email">Destinataire</label>
                </div>

            </div>
            <div class="form-row">
                <div class="input-data">
                    <input type="text" name="sujet" required>
                    <div class="underline"></div>
                    <label for="sujet">Sujet du mail</label>
                </div>
            </div>
            <div class="form-row">
                <div class="input-data textarea">
                    <textarea rows="8" cols="80" name="message" required></textarea>
                    <br />
                    <div class="underline"></div>
                    <label for="message">Contenu du mail</label>
                    <br />
                    <div class="form-row submit-btn">
                        <div class="input-data">
                            <div class="inner"></div>
                            <input type="submit" value="submit" name="submit">
                        </div>
                    </div>
        </form>
        </div>
    </div>
</body>

</html>
