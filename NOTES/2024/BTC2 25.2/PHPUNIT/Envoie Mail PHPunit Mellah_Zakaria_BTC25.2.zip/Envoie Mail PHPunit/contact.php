<?php
// Fonction pour saisir les données depuis le terminal
function prompt($prompt_msg)
{
    echo $prompt_msg;
    $input = rtrim(fgets(STDIN), "\n");
    return $input;
}

// Saisie des informations depuis le terminal
$name = prompt("Nom: ");
$email = prompt("Email: ");
$subject = prompt("Sujet: ");
$message = prompt("Message: ");

// Configuration de l'email
$to = "testipform@robot-mail.com";
$headers = "From: $name <$email>";

// Envoi de l'email
if (mail($to, $subject, $message, $headers)) {
    echo "Message envoyé avec succès!\n";
    $data = "$name | $email | $subject | $message\n";
    file_put_contents('messages.txt', $data, FILE_APPEND);
} else {
    echo "Erreur lors de l'envoi du message.\n";
}
