<?php

use PHPUnit\Framework\TestCase;

class TestsUnitaires extends TestCase
{
    public function testEmailSending()
    {
        $name = 'Test';
        $email = 'Test@example.com';
        $subject = 'Test Subject';
        $message = 'Test Message';

        $to = 'testipform@robot-mail.com';
        $headers = "From: $name <$email>";

        $result = mail($to, $subject, $message, $headers);

        $this->assertFalse($result, 'Failed to send email');
    }
}

?>
