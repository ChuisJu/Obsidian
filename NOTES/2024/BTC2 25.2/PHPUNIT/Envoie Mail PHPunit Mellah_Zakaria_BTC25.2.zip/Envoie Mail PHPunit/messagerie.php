<?php
// Lire les données depuis le fichier
$messages = file('messages.txt');

// Vérifier s'il y a des messages
if (!empty($messages)) {
    // Afficher les messages
    foreach ($messages as $message) {
        // Diviser la ligne en utilisant le séparateur '|'
        $data = explode('|', $message);

        // Afficher les données
        echo "<strong>Nom:</strong> " . trim($data[0]) . "<br>";
        echo "<strong>Email:</strong> " . trim($data[1]) . "<br>";
        echo "<strong>Sujet:</strong> " . trim($data[2]) . "<br>";
        echo "<strong>Message:</strong> " . trim($data[3]) . "<br><br>";
    }
} else {
    echo "Aucun message n'a été enregistré.";
}
?>
