<?php

use PHPUnit\Framework\TestCase;

require_once 'fonction.php';

class testFonction extends TestCase
{
    private $logFile = 'logfile.log';

    public function testLogMessage()
    {
        $expediteur = "test@expediteur.net";
        $destinataire = "test@destinataire.net";
        $sujet = "Test sujet";
        $message = "Ceci est un message de test.";

        logMessage($expediteur, $destinataire, $sujet, $message);

        $this->assertFileExists($this->logFile);

        $logContent = file_get_contents($this->logFile);
        $this->assertStringContainsString($expediteur, $logContent);
        $this->assertStringContainsString($destinataire, $logContent);
        $this->assertStringContainsString($sujet, $logContent);
        $this->assertStringContainsString($message, $logContent);
    }
}
