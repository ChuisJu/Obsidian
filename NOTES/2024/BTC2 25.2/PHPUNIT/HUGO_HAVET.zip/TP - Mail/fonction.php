<?php 

if (isset($_POST['sujet']) && isset($_POST['message'])){
    $expediteur = "h.havet@ecole-ipssi.net";
    $destinataire = "j.dubois@ecole-ipssi.net";
    
    $sujet = htmlspecialchars($_POST["sujet"]);
    $message = htmlspecialchars($_POST["message"]);


    if(logMessage($expediteur, $destinataire, $sujet, $message)){
        echo "Mail enregistré";
    }
}

function logMessage($expediteur, $destinataire, $sujet, $message) {
    $logFile = 'logfile.log';
    
    $logEntry = "[" . date('Y-m-d H:i:s') . "] Expéditeur : [$expediteur], Destinataire : [$destinataire], Sujet : [$sujet],  Message : [$message]" . PHP_EOL;
    
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}
?>