<?php
require "contact.php";

if (isset($_POST["submit"])) {
    $to = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $name = $_POST["yourname"];
    $error = array();

    // there only subject with length<25 characters are accepted
    if (strlen($subject) <= 25) {
        $subject = $subject;
    } else {
        array_push($error, "invalid subject -- Need minus 25 character");
    };
    // Check for mail validation
    if (verifMail($to) != TRUE) {
        array_push($error, "invalid email");
    } else {
        $to = $to;
    };
    // Check for name validation
    if (verifName($name) != TRUE) {
        array_push($error, "invalid name -Need name without special characters and numbers -(this =>(é or à) are special characters)");
    } else {
        $additional_headers = [
            "From" => $_POST["yourname"]
        ];
    };
    // Check if array (error) is empty before send mail else display an error message
    if (!empty($error)) {
        echo "erreur";
        print_r($error);
    } else {
        sendmail($to, $subject, $message, $additional_headers);
    }
    return;
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> mail</title>

</head>

<body>
    <h2>Form to send an Email</h2>

    <form method="POST">
        <br><br><br>
        <label for="name">Your name :</label>
        <input type="name" name="yourname" placeholder="yourname" required>
        <br><br>
        <label for="email">Send Mail To :</label>
        <input type="email" name="email" placeholder="to" required>
        <br><br>
        <label for="objet">Subject :</label>
        <input type="text" name="subject" placeholder="subject">
        <br><br>
        <label for="message">Your message</label>
        <br>
        <textarea name="message" cols="35" rows="10"></textarea>
        <br><br>
        <input type="submit" name="submit" value="Valider">
    </form>


</body>


</html>