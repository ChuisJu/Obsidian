<?php



// This function check if name contains only letters without accent to;
function verifName($name)
{

    if (ctype_alpha($name)) {
        $y = TRUE;
    } else {
        $y = FALSE;
    };
    return $y;
};
// This function check if mail is valid 
function verifMail($mail)
{
    if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        $x = TRUE;
    } else {
        $x = FALSE;
    };
    return $x;
};



function sendmail($to, $subject, $message, $additional_headers)
{

    if (mail($to, $subject, $message, $additional_headers)) {
        echo "Email envoyé avec succès à $to ...";
    } else {
        echo "Échec de l'envoi de l'email..fg.";
    };
};
