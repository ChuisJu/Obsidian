CREATE DATABASE gestion_utilisateurs;

use gestion_utilisateurs;

CREATE TABLE secteur(
ID INT PRIMARY KEY AUTO_INCREMENT,nom VARCHAR(50));

CREATE TABLE entreprise(
ID INT PRIMARY KEY AUTO_INCREMENT,nom VARCHAR(50),adresse VARCHAR(55),nbEmploye INT ,idSecteur INT, FOREIGN KEY(idSecteur) REFERENCES secteur(ID));

CREATE TABLE utilisateurs(
ID INT PRIMARY KEY AUTO_INCREMENT,nom VARCHAR(50),prenom VARCHAR(50),age INT,mail VARCHAR(50), mdp VARCHAR(255),idEntreprise INT, FOREIGN KEY(idEntreprise) REFERENCES entreprise(ID)); 

INSERT INTO secteur(id,nom)VALUES
(1,'Zaki'),
(2,'Alex'),
(3,'Matisma'),
(4,'Babacar'),
(5,'Jason'),
(6,'Stive'),
(7,'Hugo'),
(8,'Nolan'),
(9,'Jordan'),
(10,'Paul');

INSERT INTO entreprise(id,nom,adresse,nbEmploye,idSecteur)VALUES
(1,'TOTALENERGIES','2 place Jean Millier 92400 Courbevoie',100000,1),
(2,'CAPGEMINI','11 rue de Tilsitt 75017 Paris',270000,2),
(3,'CMA CGM','4 quai d’Arenc 13002 Marseille',110000,3),
(4,'AIRBUS','2 rond-point Maurice Bellonte 31700 Blagnac',130000,4),
(5,'CARREFOUR','93 avenue de Paris 91300 Massy',320000,5),
(6,'SANOFI','54rue La Boétie 75008 Paris',100000,6),
(7,'VEOLIA ENVIRONNEMENT','21 rue La Boétie 75008 Paris',170000,7),
(8,'ORANGE','78 rue Olivier de Serres 92130 Issy-les-Moulineaux',140000,8),
(9,'VINCI','1 cours Ferdinand de Lesseps 92000 Nanterre',220000,9),
(10,'LVMH MOET HENNESSY LOUIS VUITTON','22 avenue Montaigne 75008 Paris',150000,10);


INSERT INTO utilisateurs(id,nom,prenom,age,mail,idEntreprise)VALUES 
(1,'Dupont','Jean',25,'jdupont@example.com',1),
(2,'Durand','Marie',32,'mdurand@example.com',2),
(3,'Martin','Pierre',28,'pmartin@example.com',3),
(5,'Leroy','Julie',24 ,'jleroy@example.com',4),
(6,'Moreau','Luc',35,'lmoreau@example.com',5),
(7,'Petit','Emma',22,'epetit@example.com',6),
(8,'Roul','Paul',31,'proux@example.com',7),
(9,'Lefebvre','Anna',27,'alefebvre@example.com',8),
(10,'Garcia','Marc',29,'mgarcia@example.com',9);
