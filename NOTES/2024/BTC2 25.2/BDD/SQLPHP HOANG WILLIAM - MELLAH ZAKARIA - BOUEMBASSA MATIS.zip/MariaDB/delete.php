<?php
//Ici nous avons notre fonction delete qui va nous permettre de pouvoir supprimer nos users//
    require 'database.php';
  
        $ID = $_POST['ID'];
        $sqlform = "DELETE FROM utilisateurs WHERE ID = :ID"; 
        $stmt = $db->prepare($sqlform);
        $stmt->bindParam(':ID', $ID);
        $stmt->execute();
        header('Location: index.php');


?>