<?php
//Ce code va nous permettre de faire le lien avec notre base de données//
    define('HOST', 'localhost');
    define('DB_NAME', 'gestion_utilisateurs');
    define('USER', 'root');
    define('PASS', 'root');

    try{
        $db = new PDO("mysql:host=" . HOST . ";dbname=" . DB_NAME, USER, PASS);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e){
        echo $e;
    }
?>