<?php 
    session_start();
    require 'database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="index.css" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MariaDB</title>
</head>

<!--ici nous avons le bouton logout pour se deconnecter avec le formulaire ci dessous-->
<!-- Nous avons également message d'accueil pour les utilisateurs connectés-->

    <body>

        <?php if(isset($_SESSION['data'])){ ?>
            <h2> Bienvenue <?php echo $_SESSION['data']['nom'] .' ' .$_SESSION['data']['prenom'] ?> </h2>
        <form method="post" action="logout.php">
    <h4> 
        <br>
        <button class="disconbutton" type="submit" class="btn btn-danger" name='deconnexion' value="Déconnexion"><h3>Déconnexion</h3></button>     
       
        </form>
       <?php } ?>
       <!--Ici nous avons notre tableau avec les informations de nos utilisateurs-->
        <table>
 <h2><center> Liste des Utilisateurs </center> </h2>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prenom</th>
                <th>Age</th>
                <th>Mail</th>
                <th>Nom Entreprise</th>
                <th>Adresse</th>
                <th>Nombre d'employé</th>
                <th>Secteur</th>

                

            </tr>
        </thead>
        <tbody>

        <?php 
        // Ici nous avons la requete pour afficher nos utilisateurs  //
        
        $sql = "SELECT utilisateurs.ID AS ID, utilisateurs.nom AS nom, prenom, age, mail, entreprise.nom AS nomEntreprise, adresse, nbEmploye, secteur.nom AS nomSecteur FROM utilisateurs INNER JOIN entreprise ON utilisateurs.idEntreprise = entreprise.id INNER JOIN secteur ON entreprise.IDSecteur = secteur.id";

        $result = $db->query($sql);
      
        while($row = $result->fetch(PDO::FETCH_ASSOC)){

        
            ?>

            
                <tr>
                        
                    <td><?php echo $row['ID']; ?></td>
                    <td><?php echo $row['nom'];?></td>
                    <td><?php echo $row['prenom'];?></td>
                    <td><?php echo $row['age'];?></td>
                    <td><?php echo $row['mail'];?></td>
                    <td><?php echo $row['nomEntreprise'];?></td>
                    <td><?php echo $row['adresse'];?></td>
                    <td><?php echo $row['nbEmploye'];?></td>
                    <td><?php echo $row['nomSecteur'];?></td>
                    <td>
                    <form action="delete.php" method="POST">
                        <input type="hidden" name="ID" value="<?php echo $row['ID'] ?>">
                        <input type="submit" value="delete" style= "color: red">
                    </form>
                    </td>
                </tr>
            
            <?php

        };
        
        
        ?>
        </tbody>

        </table>
        <!-- Formulaire creation utilisateurs-->
        <h2><center> Creation des Utilisateurs </center> </h2>
    <div class="form">
        <form method="POST" action="form.php">
        <label for="nom">Nom:</label>
        <input type="text" name="nom">
        <label for="prenom">Prenom:</label>
        <input type="text" name="prenom">
        <label for="age">Age:</label>
        <input type="number" name="age">
        <label for="mail"> E-mail: </label>
        <input type="email" name="mail">
        <label for="motdepasse"> Mot de passe: </label>
        <input type="password" name="motdepasse">
        <label for="nomE"> Entreprise: </label>
        <input type="text" name="nomE">
        <label for="adresse"> Adresse Entreprise: </label>
        <input type="text" name="adresse">
        <label for="nbEmploye"> Nombre d'employé </label>
        <input type="number" name="nbEmploye">
        <label for="Secteur"> Secteur : </label>
        <select name="Secteur">
            <option value="1" selected>Zaki</option>
            <option value="2">Alex</option>
            <option value="3">Matisma</option>
            <option value="4">Babacar</option>
            <option value="5">Jason</option>
            <option value="6">Stive</option>
            <option value="7">Hugo</option>
            <option value="8">Nolan</option>
            <option value="9">Jordan</option>
            <option value="10">Paul</option>
        </select>
        
        <input type="submit" value="Submit">
        </form> 
    </div>
    <?php 

        if(isset($_SESSION['data'])){
            ?>
             <!-- Formulaire modifcation utilisateur si connecté-->
        <h2><center> Modifier votre compte</center></h2>
        <form method="POST" action="modification.php">
        <input type="hidden" name="ID" value="<?php  echo $_SESSION['data']['ID']?>" >
        <input type="hidden" name="IDe" value="<?php echo $_SESSION['data']['idEntreprise']?>" >
        <label for="nom">Nom:</label>
        <input type="text" name="nom" value="<?php echo $_SESSION['data']['nom']?>" required>
        <label for="prenom">Prenom:</label>
        <input type="text" name="prenom" value="<?php echo $_SESSION['data']['prenom']?>" required>
        <label for="age">Age:</label>
        <input type="number" name="age" value="<?php echo $_SESSION['data']['age']?>" required>
        <label for="mail"> E-mail: </label>
        <input type="email" name="mail" value="<?php echo $_SESSION['data']['mail']?>" required>
        <label for="motdepasse"> Mot de passe: </label>
        <input type="password" name="motdepasse" required>
        <label for="nomE"> Entreprise: </label>
        <input type="text" name="nomE" value="<?php echo $_SESSION['dataE']['nom']?>" required>
        <label for="adresse"> Adresse Entreprise: </label>
        <input type="text" name="adresse" value="<?php echo $_SESSION['dataE']['adresse']?>"  required>
        <label for="nbEmploye"> Nombre d'employé </label>
        <input type="number" name="nbEmploye" value="<?php echo $_SESSION['dataE']['nbEmploye']?>"  required>
        <label for="Secteur"> Secteur : </label>
        <select name="Secteur">
            <option value="1" selected>Zaki</option>
            <option value="2">Alex</option>
            <option value="3">Matisma</option>
            <option value="4">Babacar</option>
            <option value="5">Jason</option>
            <option value="6">Stive</option>
            <option value="7">Hugo</option>
            <option value="8">Nolan</option>
            <option value="9">Jordan</option>
            <option value="10">Paul</option>
        </select>
        
        <input type="submit" value="Submit">
        </form> 






<?php
        } else {
?>

            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
         <!-- Formulaire connexion si pas connecté-->
        <form method="POST" action="login.php">

            <label for="mail">E-mail:</label>
            <input type="email" name="mail">
            <label for="motdepasse">Mot de passe:</label>
            <input type="password" name="motdepasse">
            <input type="submit" value="Login">
            
        </form>







<?php
        }
    
    
    ?>
    </body>
</html>