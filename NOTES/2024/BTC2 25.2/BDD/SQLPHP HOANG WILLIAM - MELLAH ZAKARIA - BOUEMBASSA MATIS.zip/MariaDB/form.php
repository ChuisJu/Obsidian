<?php 
//Ici nous avons nos variables de nos tables avec la méthode post qui va permettre la transmission de nos données//
        require 'database.php';
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $age = $_POST['age'];
        $mail = $_POST['mail'];
        $motdepasse = $_POST['motdepasse'];
        $motdepasse = password_hash($motdepasse, PASSWORD_DEFAULT); 
        $nomE = $_POST['nomE'];
        $adresse = $_POST['adresse'];
        $nbEmploye = $_POST['nbEmploye'];
        $Secteur = $_POST['Secteur'];
        $sql = "INSERT INTO entreprise (nom, adresse, nbEmploye, idSecteur) VALUES ('$nomE','$adresse', '$nbEmploye', '$Secteur')";
        $result = $db->query($sql);

        $sql2 = "SELECT ID FROM entreprise ORDER BY ID DESC LIMIT 1";
        $result2 = $db->query($sql2);
        $row2 = $result2->fetch(PDO::FETCH_ASSOC);
        $idEntreprise = $row2['ID'];
        $sqlform = "INSERT INTO utilisateurs (nom, prenom, age, mail, mdp, idEntreprise) VALUES (:Nom, :Prenom, :Age, :Mail, :mdp, :entreprise)";
        $stmt = $db->prepare($sqlform);
        $stmt->bindParam(':Nom', $nom);
        $stmt->bindParam(':Prenom', $prenom);
        $stmt->bindParam(':Age', $age);
        $stmt->bindParam(':Mail', $mail);
        $stmt->bindParam(':mdp', $motdepasse);
        $stmt->bindParam(':entreprise', $idEntreprise);
        $stmt->execute();
        header("location: index.php");
    

?>