<?php 
    //Destruction de la session et redirection vers la page index une fois qu'on a appuyé sur le bouton 'deconnexion'
        session_start();
        session_destroy();
        header("Location: index.php");
        exit;

?>