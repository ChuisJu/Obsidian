<?php 
//Ici nous avons notre page login qui va nous permettre de pouvoir se connecter on faisant le lien et la vérification avec la base de données//
    session_start();
    require 'database.php';
    $e = $_POST["mail"];
    $p = $_POST["motdepasse"];

    $sql = "SELECT * FROM utilisateurs WHERE mail = :mail"; 
        $result = $db->prepare($sql);
        $result->execute([
            "mail" => $e,
        ]);



    

        if($result->rowCount() > 0)
        
            {
                
                $data = $result->fetchAll();
                
                if(password_verify($p,$data[0]['mdp']))
                
                {
                    $_SESSION['data'] = $data[0];
                    $sql2 = "SELECT * FROM entreprise WHERE ID = :idEntreprise"; 
                        $result2 = $db->prepare($sql2);
                        $result2->execute([
                            "idEntreprise" => $data[0]['idEntreprise'],
                        ]);
                        $row2 = $result2->fetch(PDO::FETCH_ASSOC);
                    $_SESSION['dataE'] = $row2;
                    
                header("Location: index.php");
                }
 
            } else
            {
                echo "Identifiant ou mot de passe erroné"; 
            }




?>