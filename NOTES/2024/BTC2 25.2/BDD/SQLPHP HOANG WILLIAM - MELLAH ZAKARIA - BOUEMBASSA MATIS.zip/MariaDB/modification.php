<?php   
//ici nous avons nos tables avec nos deux entreprise et utilisateur avec les updates pour permettre la modification//
        session_start();
        require 'database.php';
        $id = $_POST['ID'];
        $ide = $_POST['IDe'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $age = $_POST['age'];
        $mail = $_POST['mail'];
        $motdepasse = $_POST['motdepasse'];
        $motdepasse = password_hash($motdepasse, PASSWORD_DEFAULT); 
        $nomE = $_POST['nomE'];
        $adresse = $_POST['adresse'];
        $nbEmploye = $_POST['nbEmploye'];
        $Secteur = $_POST['Secteur'];
    

        $sql2 = "UPDATE entreprise SET nom = :Nom, adresse = :Adresse, nbEmploye = :nbEmploye, idSecteur = :Secteur WHERE ID = :ID";
        $stmt2 = $db->prepare($sql2);
        $stmt2->bindParam(':Nom', $nomE);
        $stmt2->bindParam(':Adresse', $adresse);
        $stmt2->bindParam(':nbEmploye', $nbEmploye);
        $stmt2->bindParam(':Secteur', $Secteur);
        $stmt2->bindParam(':ID', $ide);
        $stmt2->execute();


        $sql = "UPDATE utilisateurs SET nom = :Nom, prenom = :Prenom, age = :Age, mail = :Email, mdp = :mdp WHERE ID = :ID";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':Nom', $nom);
        $stmt->bindParam(':Prenom', $prenom);
        $stmt->bindParam(':Age', $age);
        $stmt->bindParam(':Email', $mail);
        $stmt->bindParam(':mdp', $motdepasse);
        $stmt->bindParam(':ID', $id);
        $stmt->execute();
        header("location: index.php");
    
?>