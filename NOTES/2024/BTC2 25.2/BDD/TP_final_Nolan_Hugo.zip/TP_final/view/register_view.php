<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="../assets/css/signup.css">
        <title>Ajout uttilisateur</title>
    </head>
    <body>

        <?php 
        if(isset($_GET['erreur'])){
            $erreur = $_GET['erreur'];
            echo '<script>window.alert("' . $erreur . '");</script>';
        }
        $type = $_GET['type'];?>

            <form method="POST" action="../controllers/register_controller.php">
                <h2>Inscription</h2>
                <div class="username">         
                    <input type="text" name="nom" placeholder="Nom" required="required">
                </div>
                <div class="username">         
                    <input type="text" name="prenom" placeholder="Prenom" required="required">
                </div>
                <div class="username">         
                    <input type="text" name="age" placeholder="age" required="required">
                </div>
                <div class="email">
                    <input type="email" name="email" placeholder="Email" required="required">
                </div>
                <div class="password">
                    <input type="password" name="password" placeholder="Mot de passe" required="required">
                </div>
                <button type="submit" name="validate">Ajouter</button>
                <br><br>
        </form>';
</body>
</html>