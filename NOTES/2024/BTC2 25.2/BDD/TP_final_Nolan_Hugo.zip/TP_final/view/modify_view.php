<html>
    <head>
        <meta charset="UTF-8">
        <title>Modifier</title>
        <link rel="stylesheet" type="text/css" href="../assets/css/modify.css">
        <script src="https://kit.fontawesome.com/43eb508cc8.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php 
            echo '<h1>Modifier l\'utilisateur</h1>
            <form method="POST">
                <input type="text" name="nom" value="' . $user['nom'] . '"placeholder="Nom"><br><br>
                <input type="text" name="prenom" value="' . $user['prenom'] . '"placeholder="Prénom"><br><br>
                <input type="text" name="age" value="' . $user['age'] . '"placeholder="Age"><br><br>
                <input type="email" name="email" value="' . $user['mail'] . '"placeholder="Email"><br><br>';
            echo '
                <button type="submit" class="button"><i class="fa-regular fa-floppy-disk" style="color: #ffffff;"></i></button>
            </form>';
        ?>
    </body>
</html>