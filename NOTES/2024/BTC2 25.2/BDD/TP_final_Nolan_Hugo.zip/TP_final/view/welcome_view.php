<html>
    <head>
        <meta charset="UTF-8">
        <title>Accueil</title>
        <link rel="stylesheet" type="text/css" href="../assets/css/welcome.css">
        <script src="https://kit.fontawesome.com/43eb508cc8.js" crossorigin="anonymous"></script>
        <script src="../controllers/js/popUp.js"></script>
    </head>
    <body>
        <?php 
        session_start();
        echo '<h3>Bienvenue ' . $_SESSION['prenom'] . '<br><h3>';
        echo 'Nom : ' . $_SESSION['nom'] . '<br>Age : ' . $_SESSION['age'] . '<br>Mail : ' . $_SESSION['mail'] . '</h3>';
        ?>

        <a href='manage_view.php'>Afficher user</a>


    </body>
</html>