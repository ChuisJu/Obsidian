<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/manage.css">
    <script src="https://kit.fontawesome.com/43eb508cc8.js" crossorigin="anonymous"></script>
</head>
<body>
<?php
require_once '../assets/database/config.php';

function getUtilisateurs($bdd) {
    $recupUser = $bdd->query('SELECT id, nom, prenom, age, mail FROM utilisateurs');
    $utilisateurs = $recupUser->fetchAll();
    $recupUser->closeCursor();
    return $utilisateurs;
}

$utilisateurs = getUtilisateurs($bdd);

echo '<div class="titre">
        <h1>Gestion utilisateurs</h1>
        <a href="register_view.php"><button>Ajouter un utilisateur</button></a>
      </div>
      <table>
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Âge</th>
            <th>Mail</th>
            <th>Modifier</th>
            <th>Supprimer</th>
        </tr>';

foreach ($utilisateurs as $user) {
    echo '<tr>
            <td>' . htmlspecialchars($user['nom']) . '</td>
            <td>' . htmlspecialchars($user['prenom']) . '</td>
            <td>' . htmlspecialchars($user['age']) . '</td>
            <td>' . htmlspecialchars($user['mail']) . '</td>
            <td><a href="../controllers/modify_controller.php?id=' . $user['id'] . '"><i class="fa-solid fa-user-pen" style="color: #000000;"></i></a></td>
            <td><a href="../controllers/delete_controller.php?id=' . $user['id'] . '"><i class="fa-solid fa-trash-can" style="color: #000000;"></i></a></td>
          </tr>';
}

echo '</table>';
?>
</body>
</html>
