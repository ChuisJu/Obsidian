<?php 
session_start();
require_once '../assets/database/config.php';

// Assurez-vous que $bdd est correctement initialisé dans config.php
global $bdd;

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    function getUserById($id){
        global $bdd;
        $recupUser = $bdd->prepare('SELECT nom, prenom, age, mail, id FROM utilisateurs WHERE id = ?');
        $recupUser->execute(array($id));

        if($recupUser->rowCount() > 0){
            return $recupUser->fetch();
        }
        return null;
    }

    $user = getUserById($id);
    include('../view/modify_view.php');

    function modifyUsers($nom, $prenom, $age, $email, $id){
        global $bdd;
        $updateUser = $bdd->prepare('UPDATE utilisateurs SET nom = ?, prenom = ?, age = ?, mail = ? WHERE id = ?');
        $updateUser->execute(array($nom, $prenom, $age, $email, $id));
    }

    // Modification pour utiliser $_POST et les bons noms de champs
    if(isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['age']) && isset($_POST['email'])){
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $age = $_POST['age'];
        $email = $_POST['email'];
    
        modifyUsers($nom, $prenom, $age, $email, $id);
        header('Location: ../view/manage_view.php');
        exit;
    }
}
?>
