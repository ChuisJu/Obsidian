<?php
session_start();
require '../assets/database/config.php';

if(isset($_POST['validate'])){
    $user_nom = htmlspecialchars($_POST['nom']);
    $user_prenom = htmlspecialchars($_POST['prenom']);
    $user_age = ($_POST['age']);
    $user_email = ($_POST['email']);
    $user_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        $insertUserOnWebsite = $bdd->prepare('INSERT INTO utilisateurs(nom, prenom, password, age, mail) VALUES(?, ?, ?, ?, ?)');
        $insertUserOnWebsite->execute(array($user_nom, $user_prenom, $user_password, $user_age, $user_email));
    } catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
    }

    header('Location : ../manage_view.html');
}

elseif(!isset($_POST)){
    $erreur = "Error 401";
    echo '<script>window.alert("' . $erreur . '");</script>';
}