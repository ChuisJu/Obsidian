<?php
session_start();
require_once '../assets/database/config.php';

if(isset($_POST['validate'])) {

    $user_pseudo = $_POST['prenom'];
    $user_password = $_POST['password'];
    verifUser($user_pseudo, $user_password);
    header('Location: ../view/welcome_view.php');
    exit;
}

if(isset($_GET['erreur'])){
    $erreur = "Identifiant ou mot de passe incorrect";
    echo '<script>window.alert("' . $erreur . '");</script>';
}

include_once('../view/login_view.html');

function verifUser($user_pseudo, $user_password){
    
    global $bdd;
    $checkIfUserExists = $bdd->prepare('SELECT id, nom, prenom, password, age, mail FROM utilisateurs WHERE prenom = ?');
    $checkIfUserExists->execute(array($user_pseudo));

    if($checkIfUserExists->rowCount() > 0){
    $usersInfos = $checkIfUserExists->fetch();

        if(password_verify($user_password, $usersInfos['password'])){

            $_SESSION['auth'] = true;
            $_SESSION['id'] = $usersInfos['id'];
            $_SESSION['nom'] = $usersInfos['nom'];
            $_SESSION['prenom'] = $usersInfos['prenom'];
            $_SESSION['password'] = $usersInfos['password'];
            $_SESSION['age'] = $usersInfos['age'];
            $_SESSION['mail'] = $usersInfos['mail'];
        } 
        } 
}