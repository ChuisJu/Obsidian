<?php
require_once '../assets/database/config.php';

$id = $_GET['id'];

function deleteUsers($id){
    global $bdd;
    $recupUser = $bdd->prepare('SELECT id FROM utilisateurs WHERE id = ?');
    $recupUser->execute(array($id));

    if($recupUser->rowCount() > 0){
        $suppUser = $bdd->prepare('DELETE FROM utilisateurs WHERE id = ?'); // Correction de la table (utilisateurs au lieu de utilisateurss)
        $suppUser->execute(array($id));
    }
}

deleteUsers($id);
header('Location: ../view/manage_view.php');
exit;
?>
