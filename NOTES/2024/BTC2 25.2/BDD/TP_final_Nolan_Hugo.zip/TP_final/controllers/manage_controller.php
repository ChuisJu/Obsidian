<?php 
session_start();
require_once '../assets/database/config.php';


function getUtilisateurs() {
    global $bdd;
    $recupUser = $bdd->query('SELECT pseudo, email, role, id FROM user');
    $utilisateurs = $recupUser->fetchAll();
    $recupUser->closeCursor();
    return $utilisateurs;
}

    $utilisateurs = getUtilisateurs();

include_once('../view/manage_view.php');